# T020 G2 standalone staged-source delivery

READY for scoped SOURCE/MANUAL-GRAPH preparation only. Actual same-functionality,
adversarial and architect final reports approve exact607-file source manifest:
SOURCE-HASHES.json SHA25659c355692dda28e57986ddc9d8f88b9e56666cf98fe30d60919e4fe2fb4d898b.
Cargo resolution, compilation and every native/runtime check remain HOLD.

Owned standalone stage /private/tmp/ktlsp-t020-g2-stage. Root admitted this source
scope only. Managed worktree /Users/anil/.codex/worktrees/t020-g2-packet/ktlsp,
branch codex/t020-g2-packet, remains clean at941c72efd9896b0847ab342ec0dd22c10a000f3b/
treec9a8c8ae5ee4984b6b21849007bafbeebea33975. Product source/Cargo/lock/workflows,
status docs, registry cache and other-owner worktrees remain unchanged. No push,
issue/PR, CI dispatch, merge, workflow file or settings change occurred.

Reach implemented inside this copy only: frozen four decoder module snapshots
and notices; baseline145 artifacts files, preserving108 stored fixture/test
expectations; one private shared envelope extraction/CRC, carrying original
work balance/phase order; bounded method8 wrapper with distinct WorkLimit;
accepted and separately identified diagnostic packages;125 literal cases from
90old/35new inputs; atomic System allocator/usable-size hooks;1MiB-thread child,
K0-K6 calibration/stack negative control, fixed512-byte receipts; bounded serial
supervisor with cleanup evidence/minimal environment; fully bound root-admission
and calibration receipt identities; proposed D/R profile/target settings.

The accepted core/shared/output_buffer snapshots remain byte-identical to meter
source; parent is frozen prefix+include. Diagnostic core/layout/branch probes are
separate source/artifact hashes and cannot supply accepted physical measurements.
Actual compiled frame/copy evidence must include overlapping harness observer/
driver and linked helpers; unavailable coverage is HOLD, not an array-size proof.

Each manual lock has13 packages (2local+11registry). Full existing target/build
edges, package checksums and archived sources are retained, including inactive
cpufeatures/libc paths. No Cargo command resolved or accepted this lock; --locked
acceptance and actual linked graph remain a compiler-stage gate. GRAPH-AUDIT.json
records manifests/features/build metadata; no C/C++ source files in those11
archives, and only existing Rust build scripts for generic-array/libc. No new
first-party build script, JVM/JDK/compiler engine/C parser/server/worker/oracle/
bench graph or dependency installation. Third-party notices preserved.

Unsafe observation reviewed as source: malloc_usable_size receives only a live
non-null align1 pointer just returned by System, or the exact live returned Vec
pointer/capacity matching the hook. Zero-capacity/dangling/foreign pointers are
excluded. Actual glibc/System/loader/helper images, environment and external
loader configuration must be bound on the later Linux executor; cfg(linux-gnu)
is not runtime binding proof. Child environment is cleared except LANG/LC_ALL=C.

Actual Linux route proposal: gh read-only workflow inventory succeeds; existing
native and optional-oracle workflows have no standalone G2 entrypoint. No local
Linux executor is configured/admitted. execution-route/PROPOSAL.md describes the
small separate dispatch-only workflow admission and finite preflight/compile/
calibration/stack-assessment/execution modes; no workflow source/mutation or
runtime is silently admitted. EXECUTOR-BOUND/admission files are absent.

Actual final same reviewers:
/root/g2_functionality -> reviews/FUNCTIONALITY-SOURCE-FINAL.md, READY scoped source/manual graph;
/root/g2_adversarial -> reviews/ADVERSARIAL-SOURCE-FINAL.md, READY source/graph only;
/root/architect -> reviews/ARCHITECT-SOURCE-FINAL.md, APPROVE staged source only.
Read-only architect response preserved verbatim by owner. Initial607 source bytes
and manifest c7e73ed retained as SOURCE-INITIAL.tar.gz/json, with actual findings
and fixes/rechecks. REVISION-NOTES.md preserves early/stale findings accurately.

Executed: source/data stdlib Python checks only, all607 hashes, baseline145 and
108fixture-count/byte preservation,125literal cases/inputs,11archive checksums/
manifest graphs, both13package closed locks, initial607 recovery hash, static
source/unsafe/profile/extraction review by SAME3, read-only Git/GitHub inventory.
Five unique small Rust unit checks are staged but UNCOMPILED/UNEXECUTED.
No Cargo/metadata/fetch/fmt/clippy/compiler/native test/decoder/compressor/DEFLATE
interpreter/parser/worker/server/bench/oracle/JVM/Gradle/Maven execution occurred.
First source-checker assertion failure was corrected/preserved, not retried
unchanged. No native passing count or physical measurement is claimed.

Next root gates: exact bound Linux/toolchain/library route, source/graph compile
admission, successful named calibration, complete accepted compiled stack/copy
assessment<=262144, then exact named candidate/diagnostic cohort admission.
Stored108 runtime preservation likewise needs explicit native validation scope.
No partial-output publication, budget reset, unchanged-failure retry, relaxed
threshold/profile or diagnostic-metric substitution. WorkLimit containment is
not compiled equivalence/useful dynamic acceptance. G2PASS/equivalence/product
integration remain pending. HDIST31/32 and descriptors remain separate exclusions;
genuine Commons396/Guava1932 classes consumed0. T008/T008a HOLD, broaderC13/B3/B4
GAP, B11 UNVERIFIED, #7/#83/#20 OPEN, #96 OPEN/Darwin UNKNOWN. No semantic,
fullT020/platform/comparativeperformance/official parity claim.

External small receipt /private/tmp/ktlsp-t020-g2-source-delivery.json records
final source/graph/review/archive hashes after preservation. Root pulls it;
no cross-chat send or routine user confirmation is required.
