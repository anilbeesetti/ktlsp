# T020 G2 staged-source adversarial review — final revision1

2026-10-14. Same reviewer `/root/g2_adversarial`. Source/graph review only;
not compilation, executor, calibration or candidate execution admission. This
report is the only file written by the reviewer during this final recheck.

## Exact reviewed artifact and verification

SOURCE-HASHES.json SHA256
`59c355692dda28e57986ddc9d8f88b9e56666cf98fe30d60919e4fe2fb4d898b`.
Independently verified all607 actual file hashes, including a final readback
before this report. Independently verified all607 initial preserved archive
members against reviews/SOURCE-INITIAL.json with reviewed SHA256
`c7e73edfe0673fb94a172500dd1e386ed8fe58987acd622f5e7d7e332358cddf`.
Only eight core paths changed: README.md, execution-route/PROPOSAL.md,
src/main.rs, src/wire.rs, supervise.rs and their three diagnostic counterparts.
The other599 files, locks, input identities, accepted core and metrics.rs are
unchanged. Read actual diffs for every changed source/design path; diagnostic
source equality except its provenance flag remains checker-verified.

Permitted `python3 check_stage.py`: PASS source/data only, baseline145,
stored_fixture_cases108, cases125=old90+new35, registry11, lock13;
Cargo resolution/compiler/native runtime all false. Registry graph/archive
metadata verification from the initial review remains applicable to unchanged
archives/locks/graph records. An initial preservation lookup incorrectly assumed
the source manifest was inside its archive; that read-only lookup failed and
was corrected by using the retained separately hashed initial manifest. All
preservation checks then passed; no source bytes or expectations were changed.

## Verdict: READY for source/graph review only

S1 and S2 are resolved. No actionable adversarial source finding remains on this
exact607-file stage. This is not a claim of compilability, Cargo lock acceptance,
unsafe allocator binding, native safety, G2 PASS or product readiness.

### S1 resolved — bounded preopened proc observer

ProcReader owns one preopened /proc/self/status descriptor and reusable16384-byte
buffer. Full-EOF bounded reads reject overflow, read errors and truncation; the
buffer/descriptor are warmed before the baseline and remain outside allocator
windows. parse_memory checks UTF8, duplicate/missing RSS/HWM fields, kB units,
extra fields and conversion overflow. Runtime parsing test sources cover exact
buffer size versus excess and malformed fields, but remain unexecuted.
Maps use bounded65536-byte storage and the same full-EOF rule, without a growing
String or Vec. Driver/observer storage is explicitly included in the later
inclusive emitted-stack assessment, not hidden behind decoder-only array sizes.

### S2 resolved — lower guard and complete span receipt

The sole x86_64 stack mapping must be private rw-p, exactly1048576 bytes, with a
private inaccessible ---p lower mapping ending exactly at stack start and size
at least4096. Upper-only guards no longer satisfy the check. Word63 records
actual stack start; words13/14 retain stack/guard lengths, deriving complete
adjacent spans. Supervisor validates subtraction/addition range safety for
ordinary/calibration receipts. Negative control uses the same mapping check
before READY and remains separately fatal-signal corroboration. Whole4096-byte
frame retention and inclusive maximum stack still require emitted-code review.

## Other changed protections rechecked

- Calibration receipts now bind role, profile, child ELF, source manifest, correct
  accepted/diagnostic lock, executor and exact calibration-admission identity.
  Candidate admission rechecks both calibration and execution identity gates;
  stale calibration from another context cannot satisfy equality. Child role
  provenance is checked during calibration.
- Supervisor hashes streams with fixed16KiB storage; admission/calibration text
  retains at most4096 bytes and rejects overflow/read errors/invalid UTF8.
  Existing bounded pipe draining, capture-error retention, first-failure stop,
  OS cleanup/status-before-joins and env_clear protections remain intact.
- Core Done counts are checked before slicing, so a corrupt overlarge written
  count produces FAIL instead of a new observer bounds panic. Frozen expected
  hashes/counts/errors/phases remain strict; WorkLimit allowances are unchanged.
- Added Rust parser/wire/pipe tests are source only and do not claim execution.
  No new native runtime, dependency or product source change was introduced.

The unchanged allocator hooks only call malloc_usable_size on known non-null
live System align1 pointers, and retained Vec observations also verify pointer/
capacity/alignment and one-allocation history. Safety still depends on the
explicitly unresolved root Linux preflight binding of actual System/glibc/
loader/interposition/IFUNC configuration. No source approval substitutes for it.

No actual standalone Linux route/workflow is admitted, admission/executor files
are absent, manual Cargo locks remain unaccepted by Cargo, calibration/negative
controls and Rust unit sources remain unexecuted. Compiled stack/copy/helper
coverage, allocation/RSS/panic outcomes and all108 stored runtime outcomes remain
future exact-source/graph/executor gates. Dynamic/full compiled equivalence,
HDIST31/32, descriptors and semantic/platform parity are not established.

Skipped compilation, Cargo and runtime. Allocator binding and compiled/native
stack, allocation and panic acceptance remain unverified and separately gated.
