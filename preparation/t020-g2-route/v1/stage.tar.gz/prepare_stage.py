"""Source/data staging only; never invokes Cargo, Rust or candidate code."""
from pathlib import Path
import shutil, hashlib, json, tarfile, tomllib
ROOT=Path(__file__).resolve().parent
BASE=Path('/Users/anil/.codex/worktrees/t020-g2-packet/ktlsp')
METER=Path('/private/tmp/ktlsp-t020-work-meter/preparation/t020-meter')
PACKET=Path('/private/tmp/ktlsp-t020-g2-packet')
sha=lambda b:hashlib.sha256(b).hexdigest()
baseline=BASE/'crates/ktlsp-artifacts'
dest=ROOT/'artifacts-under-test'
assert not dest.exists(), 'do not overwrite staged changes'
shutil.copytree(baseline,dest)
original={str(p.relative_to(baseline)):sha(p.read_bytes()) for p in sorted(baseline.rglob('*')) if p.is_file()}
(ROOT/'evidence/BASELINE-HASHES.json').write_text(json.dumps(original,indent=2)+'\n')
# Extract existing validation as text; all existing phase/error/order text retained.
p=dest/'src/zip_stored.rs';s=p.read_text()
start=s.index('        let entry = self\n')
end=s.index('        charge(&mut work, size, MAX_WORK, p, "stored work units")',start)
body=s[start:end]
body=body.replace('if entry.method != 0 {','if entry.method != selected_method {').replace('if method != 0 {','if method != selected_method {')
body=body.replace('if compressed != uncompressed {','if selected_method == 0 && compressed != uncompressed {')
body=body.replace('limit(size, MAX_PAYLOAD, p, "stored payload bytes")', 'limit(size, MAX_PAYLOAD, p, if selected_method == 0 { "stored payload bytes" } else { "deflated compressed bytes" })')
body=body.replace('MAX_PAYLOAD','MAX_SELECTED_PAYLOAD')
crcstart=s.index('fn crc32(bytes: &[u8])')
crcend=s.index('\n#[cfg(test)]',crcstart)
crc=s[crcstart:crcend]
new=s[:start]+'''        let selected = self.selected_envelope(ordinal, 0)?;
        let mut work = selected.work;
        let size = selected.payload.len();
        let p = selected.payload_offset;
        let payload = selected.payload;
        let expected = selected.crc;
'''+s[end:crcstart]
new=new.replace('        let payload = &self.bytes[p..q];\n','').replace('if actual != entry.crc32 {','if actual != expected {').replace('expected: entry.crc32,','expected,')
new=new.replace('MAX_EXTRA, MAX_NAME, ZipDirectoryIndex, ZipIndexError, charge, limit, malformed, u16_at, u32_at,','MAX_EXTRA, MAX_NAME, ZipDirectoryIndex, ZipIndexError, charge, crc32,')
new+=s[crcend:]
p.write_text(new)
p=dest/'src/zip_index.rs'
extra='''
// Standalone G2 copy only. Product source is unchanged.
const MAX_SELECTED_PAYLOAD: usize = 8 * 1024 * 1024;
const LOCAL: &[u8] = b"PK\\x03\\x04";
struct SelectedEnvelope<'a> {
    payload: &'a [u8], payload_offset: usize, local_offset: usize,
    declared: u32, crc: u32, work: usize,
}
impl<'a> ZipDirectoryIndex<'a> {
    fn selected_envelope(&self, ordinal: usize, selected_method: u16) -> Result<SelectedEnvelope<'a>, ZipStoredError> {
'''+body+'''        Ok(SelectedEnvelope { payload: &self.bytes[p..q], payload_offset: p,
            local_offset: h, declared: entry.uncompressed_size, crc: entry.crc32, work })
    }
}
'''+crc+'''
#[path = "zip_deflate_private/mod.rs"]
mod zip_deflate_private;
pub use zip_deflate_private::{ZipDeflateError, ProbePhases, ProbeOutcome, CoreReport,
    DiagnosticReport, __g2_core, __g2_diagnostics, __g2_phase_reset, __g2_phases};
'''
p.write_text(p.read_text()+extra)
p=dest/'src/lib.rs';p.write_text(p.read_text()+'''
// Standalone-only G2 access. Never copied to shipped workspace.
pub use zip_index::{ZipDeflateError, ProbePhases, ProbeOutcome, CoreReport,
    DiagnosticReport, __g2_core, __g2_diagnostics, __g2_phase_reset, __g2_phases};
''')
private=dest/'src/zip_deflate_private';private.mkdir()
(ROOT/'frozen').mkdir()
for name in ('mod','core','output_buffer','shared'):
    data=(METER/f'proposal/{name}.rs.txt').read_bytes()
    (ROOT/f'frozen/{name}.rs.txt').write_bytes(data)
    (private/f'{name}.rs').write_bytes(data+(b'\ninclude!("wrapper.rs");\n' if name=='mod' else b''))
notices=dest/'third-party/miniz_oxide-0.8.9';notices.mkdir(parents=True)
for p in (METER/'original/miniz_oxide-0.8.9').glob('LICENSE*.txt'):
    shutil.copy2(p,notices/p.name)
p=dest/'Cargo.toml';p.write_text(p.read_text()+'''\n[dependencies.adler2]\nversion = "=2.0.1"\ndefault-features = false\nfeatures = []\n''')
manifest=json.loads((PACKET/'inputs.json').read_text())
(ROOT/'inputs').mkdir()
for case in manifest['old_cases']:
    for key in ('raw','zip'):
        src=Path(manifest['old_packet'])/case[f'{key}_file']
        assert sha(src.read_bytes())==case[f'{key}_sha256']
        shutil.copy2(src,ROOT/'inputs'/('old-'+src.name))
for case in manifest['new_cases']:
    for data in case['files'].values():
        src=PACKET/data['path'];assert sha(src.read_bytes())==data['sha256']
        shutil.copy2(src,ROOT/'inputs'/src.name)
shutil.copy2(PACKET/'inputs.json',ROOT/'frozen/inputs.json')
# Proposed exact lock subset, not a Cargo-resolution receipt.
lock=tomllib.loads((BASE/'Cargo.lock').read_text())
packages={x['name']:x for x in lock['package']}
names=set();pending=['sha2']
while pending:
    name=pending.pop()
    if name in names:continue
    names.add(name)
    pending.extend(packages[name].get('dependencies',[]))
records=[packages[n] for n in sorted(names)]
adler=METER/'original/adler2-2.0.1.crate'
adler_sha=sha(adler.read_bytes())
records.append(dict(name='adler2',version='2.0.1',source='registry+https://github.com/rust-lang/crates.io-index',checksum=adler_sha))
cache=Path('/Users/anil/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f')
(ROOT/'dependencies').mkdir()
for pkg in records:
    source=adler if pkg['name']=='adler2' else cache/f"{pkg['name']}-{pkg['version']}.crate"
    assert sha(source.read_bytes())==pkg['checksum'], str(source)
    shutil.copy2(source,ROOT/'dependencies'/source.name)
(ROOT/'evidence/REGISTRY-RECORDS.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(dict(baseline_files=len(original),registry_packages=len(records),new_input_files=70,old_input_files=180,cargo=False,compiler=False)))
