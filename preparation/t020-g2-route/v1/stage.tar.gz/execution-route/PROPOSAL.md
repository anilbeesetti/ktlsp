# Actual available route and next admission proposal

Source staging only. No compiler, runtime, dispatch, workflow edit/publication or
settings change is authorized or executed here.

Observed on this host: gh=/opt/homebrew/bin/gh and ssh=/usr/bin/ssh are available;
docker/podman/limactl were not found by command lookup. No configured Linux SSH
host or container executor is assumed. Read-only GitHub workflow inventory via
gh api succeeds under actual sandbox escalation review. Active workflows are
Native Rust checks/id382079133/path.github/workflows/native.yml and Optional
synthetic oracle tools/id382206101/path.github/workflows/oracle-tools.yml.
The current native workflow runs product fmt/clippy/workspace tests and has no
standalone G2 entrypoint. It is not permission to run this stage, and neither
workflow is changed/dispatched. No available admitted standalone Linux execution
route exists at this point.

Smallest proposed route: root separately admits ONE optional dispatch-only Linux
standalone workflow and publication of the reviewed stage archive on an auxiliary
branch/path. Exact workflow source and publication destination must be reviewed
before that grant. Do not modify native.yml, branch protections, repository
settings, default native test graph or release contents. No such workflow source
or mutation is produced by this source-stage assignment.

The later optional workflow needs explicit finite modes, with no automatic
transition across their gates:

1. Preflight only: choose x86_64-unknown-linux-gnu/4096-page glibc executor; record
   actual runner image release+ImageVersion, kernel/CPU, ASLR, System allocator,
   loader/libc/libpthread/libgcc hashes/versions/buildIDs, IFUNC-selected helpers,
   `/etc/ld.so.preload` absence/empty hash, toolchain manifest/component hashes,
   rustc -vV, target/linker identity and environment. Record Actions workflow/run/
   job/attempt SHA, source/graph hashes and raw receipts. No source build or
   candidate/stack control executes. ubuntu-latest is a selector, never identity.
2. Root binds exact preflight identities and separately admits compilation of
   the same76-contract/source stage on a matching immutable-image/configuration
   route. A new VM must match all admitted relevant image/library/tool identities;
   a matching label alone fails. Kernel/CPU differences require root disposition
   before compilation. If exact route cannot be bound, HOLD, not a silent fallback.
3. Compile-only accepted D/R and distinct diagnostic D/R artifacts, preserving
   ELF/assembly/IR/frame+copy inventory, graph/lock and all tool outputs. Source
   tests and calibration are NOT executed by compilation. These illustrative
   commands remain data until root grants them:

   cargo build --locked --offline --profile g2-d --workspace
   cargo build --locked --offline --profile g2-r --workspace
   cargo build --locked --offline --manifest-path diagnostic-copy/Cargo.toml --profile g2-d --workspace
   cargo build --locked --offline --manifest-path diagnostic-copy/Cargo.toml --profile g2-r --workspace

   All registry archives/checksums are preserved under dependencies/; later
   root-admitted offline cache/index provisioning or vendoring is still required.
   No Cargo resolution/cache installation has happened, so --locked readiness is
   source-reviewed graph data, not a claim Cargo already accepted the manual lock.
4. After exact source+graph and compiler evidence review, root may admit only
   calibrations. `CALIBRATION-ADMISSION-{D|R}-{accepted|diagnostic}.txt` must bind
   root approval/profile/role/child/source/graph/executor. The supervisor checks
   these seven fields against actual files before any calibration subprocess.
   Record K0-K6 and verified guarded-stack fatal control; negative-control emitted
   frame must retain the complete4096-byte object before its run is admitted.
5. Only after successful calibration AND complete inclusive compiled stack/copy
   assessment<=262144 bytes, root may issue execution admission for EACH named
   profile/role. No unresolved dynamic/helper/copy frame becomes a pass. Exact
   `EXECUTION-ADMISSION-{D|R}-{accepted|diagnostic}.txt` has nine fields: previous
   seven plus compiled_stack=complete and stack_bytes=positive<=262144. Accepted
   and diagnostic use their distinct lockfiles/executable hashes and calibration
   receipts binding role/source/graph/executor/calibration-admission identity. These root-controlled files and EXECUTOR-BOUND.json are deliberately
   absent now. Diagnostic results establish only branch/layout observations.
6. Run one serial finite cohort per admitted artifact. Stop on the first failure,
   preserve raw stdout/stderr/status even when OS cleanup fails, and retain
   ambiguous reap/join as HOLD. No retry unchanged failure, averaging peaks,
   new executor, runtime budget increase or profile substitution. Existing108
   stored tests require an explicit separate native runtime grant as well.

Supervisor/child env is minimal LANG=C/LC_ALL=C, with no inherited LD_PRELOAD,
LD_AUDIT, GLIBC_TUNABLES or MALLOC_* variables. Preflight also binds external
loader configuration and actual mapped allocator/helper images. Merely clearing
environment does not prove a clean `/etc/ld.so.preload` or the IFUNC selection.
Compilation likewise forbids unreviewed wrappers/RUSTFLAGS/PGO/sanitizer/loader
injection. Stage .cargo/config pins target CPU; profile definitions pin all other
settings. Existing platform linker/libc is infrastructure, not a C analysis engine.

G2 runtime/compiled equivalence/product integration remain HOLD. HDIST31/32 and
descriptors are separate exclusions; genuine Commons/Guava classes consumed0.
No Darwin exception, fullplatform support, speed/RAM advantage, T020 completion
or semantic parity follows this proposal.
