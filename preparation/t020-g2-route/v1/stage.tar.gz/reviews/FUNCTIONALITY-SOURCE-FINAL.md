# T020 G2 correctness/functionality final staged-source review

Reviewer: `/root/g2_functionality`, 2026-10-14.

Verdict: **READY as reviewed standalone source/manual-graph preparation only.**
All actionable initial functionality findings are repaired and their changed
source was rechecked. No remaining actionable functionality finding was
identified within this authorized static/data review. Compilation, native
execution, executor binding and G2 runtime PASS remain separately gated.

## Exact reviewed bytes

Verified all **607** files against SOURCE-HASHES.json, SHA256
`59c355692dda28e57986ddc9d8f88b9e56666cf98fe30d60919e4fe2fb4d898b`.
Read SOURCE-INITIAL.tar.gz without extraction; its607 original core files
reconstruct the exact sorted initial manifest with SHA256
`c7e73edfe0673fb94a172500dd1e386ed8fe58987acd622f5e7d7e332358cddf`.
Only eight expected docs/main/wire/supervisor paths changed. Accepted decoder,
wrapper, metrics, fixtures, baseline extraction and both manual lock graphs are
unchanged from the completed initial connected-source review.

Final `python3 check_stage.py`: **PASS source/data only**,145 baseline files,
108 stored fixtures,125 cases(90 old+35 new),11 registry archives,13 packages
per manual lock; cargo_resolution/compiler/native_runtime all false.

## Findings repaired and changed behavior rechecked

1. **Bounded observation:** ProcReader opens its descriptor before baseline,
   reuses16KiB fixed storage, rewinds and reads to complete EOF. Parsing rejects
   missing/duplicate RSS/HWM, wrong units and numeric overflow without heap
   allocation. Maps use64KiB fixed storage and the same EOF/overflow/error rule;
   UTF-8/line parse failures HOLD. The post-operation RSS observer no longer
   allocates a new String/Vec while measuring the process physical peak.
2. **Lower guard and span evidence:** mapping selection requires exact rw-p1MiB
   stack and an adjacent ---p mapping ending at its lower start, with at least
   4096 bytes. Wire63 now retains stack start; stack and lower guard spans can
   be reconstructed. Supervisor checks nonnegative lower bound and nonoverflowing
   stack end for normal/calibration receipts. Upper-only guards no longer pass.
3. **Complete calibration binding:** .ok receipt binds child/profile/role/source/
   graph/executor and the exact calibration-admission file hash. Candidate
   admission revalidates both current execution and calibration admission before
   comparing the exact full receipt. Calibration also checks accepted/diagnostic
   provenance flags. Existing per-artifact/profile gates remain explicit.

Additional changes were reviewed: supervisor hashes files in bounded chunks;
admission texts use bounded capture and reject overflow/read/UTF-8 errors;
core Done counts are validated before output slicing; five unique small Rust
unit checks cover bounded EOF, memory fields, wire rejection and pipe retention.
Those Rust checks were read as source and **not compiled or executed**.

The16KiB/64KiB observation/driver storage, constructor copies and linked helper
frames must be included in the later inclusive compiled stack inventory. Their
source sizes are not measured frame sizes. The source documentation now keeps
this obligation explicit; no budget was increased to accommodate the repair.

## Connected-source conclusions retained

- Shared selected-envelope body is exact apart from the four approved method/
  size/cap choices; CRC source is unchanged, stored accumulated work/final debit/
  phase order and borrowed output are retained.108 stored fixture/test bytes
  remain unchanged, but preservation has not yet been exercised natively.
- Accepted core/shared/output_buffer equal the meter snapshots and trusted
  parent is honestly composed from its exact prefix plus wrapper include.
  Diagnostic layout/branch insertions are distinct artifacts and cannot supply
  accepted physical measurements. No frozen-core privacy widening occurred.
- Independent initial static parsing matched all125 Rust literal rows to frozen
  metadata, ZIP headers, exact error/CRC/count/flag fields and hashes. These rows
  and inputs are unchanged. The35 new raw bit recipes were independently
  reauthored in the contract review; no decoder produced their expectations.
- Exact error/phase/heap/RSS checks, held-success Vec observation before drop,
  private WorkLimit assertions, no public partial output, K0-K6 controls and
  mandatory diagnostic slow/fast/match boundary evidence remain intact.
- All11 registry archives' checksums/Cargo dependency-target-feature metadata/
  build-script hashes and both distinct13-package manual lock edges were
  independently checked in the initial review and are unchanged. This is manual
  graph data, not a claim Cargo has resolved or accepted either lock.
- Unsafe usable-size calls observe only non-null live System align1 pointers;
  returned Vec checks exact pointer/size/alignment and skips empty capacity.
  Realloc failure preserves old ownership/Layout/content; later snapshots use
  cached numbers, never dereference freed pointers. Actual loader/glibc/System
  identity and linked implementations still require the named executor gate.
- Supervisor clears inherited child environment, serializes/bounds captures,
  preserves OS cleanup/status and stops on first failure. Unconfirmed reap/join
  remains HOLD rather than a hard-completion claim.

Not checked: no Rust/Cargo/fmt/clippy/native tests, compiler, calibration, stack
control, decoder, candidate, workflow publication or dispatch ran. --locked
acceptance, compiled bounds/equivalence, stored108 runtime preservation, product
composition, HDIST31/32/descriptors, class consumption, T020 completion and
semantic/platform parity remain unverified.
