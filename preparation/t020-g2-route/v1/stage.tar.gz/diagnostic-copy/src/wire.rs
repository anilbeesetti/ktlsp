pub const WORDS:usize=64;
pub const BYTES:usize=WORDS*8;
pub const MAGIC:u64=0x4732_5354_4147_4501;
pub const PASS:u64=0;
pub const FAIL:u64=70;
pub const WORK_LIMIT:u64=1;
pub const SUCCESS:u64=0;
pub const DECODE_REJECTED:u64=2;
pub const TRUNCATED:u64=3;
pub const OUTPUT_EXCEEDS:u64=4;
pub const INVARIANT:u64=5;
pub const TRAILING:u64=6;
pub const SIZE_MISMATCH:u64=7;
pub const CRC_MISMATCH:u64=8;
pub const COMPRESSED_LIMIT:u64=9;
pub const DECODED_LIMIT:u64=10;
pub const ALLOCATION:u64=11;
pub const FLAGS:u64=12;
pub const METHOD:u64=13;
pub const DISAGREEMENT:u64=14;
pub const OTHER_ENVELOPE:u64=15;
pub type Receipt=[u64;WORDS];
pub fn encode(r:&Receipt)->[u8;BYTES] {
    let mut out=[0;BYTES];
    for (word,chunk) in r.iter().zip(out.chunks_exact_mut(8)) { chunk.copy_from_slice(&word.to_le_bytes()); }
    out
}
pub fn decode(bytes:&[u8])->Option<Receipt> {
    if bytes.len()!=BYTES{return None;}
    let mut r=[0;WORDS];
    for (word,chunk) in r.iter_mut().zip(bytes.chunks_exact(8)) { *word=u64::from_le_bytes(chunk.try_into().ok()?); }
    (r[0]==MAGIC).then_some(r)
}
// 0magic 1id 2mode 3pass/fail 4outcome 5panic 6consumed 7written
// 8O 9capacity 10usable 11R0 12H 13stacklen 14guardlen
// 15..26allocator counts;26..29first ptr,size,align;29post-drop-live
// 30..37phase counters;37private-write-check;38..42output SHA256
// 42..48diagnostic layouts;48guard-count;49..52first guard;
// 52fast entries;53fast matches;54..57first match;57event overflow;
// 58OS pid;59diagnostic-copy flag;60calibration-evidence-ok;61post-drop-dealloc;
// 62post-drop-accounting-bad;63stack-start (guard=[start-guardlen,start), stack=[start,start+stacklen)). K4 outcome16=CoreAllocation, K5 outcome17=Panic.

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn fixed_receipt_rejects_short_or_wrong_magic() {
        let mut r=[0;WORDS];r[0]=MAGIC;r[1]=125;r[63]=0x1234;
        let bytes=encode(&r);assert_eq!(&bytes[..8],&MAGIC.to_le_bytes());assert_eq!(decode(&bytes),Some(r));
        assert!(decode(&bytes[..BYTES-1]).is_none());
        let mut bad=bytes;bad[0]^=1;assert!(decode(&bad).is_none());
    }
}
