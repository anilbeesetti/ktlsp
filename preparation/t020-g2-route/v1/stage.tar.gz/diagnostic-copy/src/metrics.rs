use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering::SeqCst};

pub struct MeteredSystem;
static ACTIVE: AtomicBool = AtomicBool::new(false);
static FAIL_ALLOC: AtomicBool = AtomicBool::new(false);
static FAIL_REALLOC: AtomicBool = AtomicBool::new(false);
static COUNTERS: [AtomicU64; 11] = [const { AtomicU64::new(0) }; 11];
static FIRST_PTR: AtomicUsize = AtomicUsize::new(0);
static FIRST_SIZE: AtomicUsize = AtomicUsize::new(0);
static FIRST_ALIGN: AtomicUsize = AtomicUsize::new(0);
static FIRST_USABLE: AtomicUsize = AtomicUsize::new(usize::MAX);
// alloc,zeroed,realloc,dealloc,failures,attempted,successful,live,peak,attempt_bound,bad
#[derive(Clone, Copy, Debug)]
pub struct Snapshot { pub counts:[u64;11], pub first:[usize;3], pub usable:usize }
fn add(index:usize, n:u64) { COUNTERS[index].fetch_add(n,SeqCst); }
fn success(ptr:*mut u8, size:usize, align:usize) {
    add(6,size as u64);
    let live=COUNTERS[7].fetch_add(size as u64,SeqCst)+size as u64;
    COUNTERS[8].fetch_max(live,SeqCst);
    if FIRST_PTR.compare_exchange(0,ptr as usize,SeqCst,SeqCst).is_ok() {
        FIRST_SIZE.store(size,SeqCst); FIRST_ALIGN.store(align,SeqCst);
        #[cfg(all(target_os="linux",target_env="gnu",target_arch="x86_64"))]
        if align==1 {
            // Non-null live pointer just returned by System malloc at align1.
            FIRST_USABLE.store(unsafe { malloc_usable_size(ptr.cast()) },SeqCst);
        }
    }
}
fn subtract(size:usize) {
    if COUNTERS[7].fetch_update(SeqCst,SeqCst,|n|n.checked_sub(size as u64)).is_err() { add(10,1); }
}
fn attempt(kind:usize,size:usize) {
    add(kind,1); add(5,size as u64);
    COUNTERS[9].fetch_max(COUNTERS[7].load(SeqCst).saturating_add(size as u64),SeqCst);
}
unsafe impl GlobalAlloc for MeteredSystem {
    unsafe fn alloc(&self, layout:Layout)->*mut u8 {
        if !ACTIVE.load(SeqCst) { return unsafe { System.alloc(layout) }; }
        attempt(0,layout.size());
        if FAIL_ALLOC.swap(false,SeqCst) { add(4,1);return std::ptr::null_mut(); }
        let ptr=unsafe { System.alloc(layout) };
        if ptr.is_null() { add(4,1); } else { success(ptr,layout.size(),layout.align()); }
        ptr
    }
    unsafe fn alloc_zeroed(&self,layout:Layout)->*mut u8 {
        if !ACTIVE.load(SeqCst) { return unsafe { System.alloc_zeroed(layout) }; }
        attempt(1,layout.size());
        if FAIL_ALLOC.swap(false,SeqCst) { add(4,1);return std::ptr::null_mut(); }
        let ptr=unsafe { System.alloc_zeroed(layout) };
        if ptr.is_null() { add(4,1); } else { success(ptr,layout.size(),layout.align()); }
        ptr
    }
    unsafe fn realloc(&self,ptr:*mut u8,layout:Layout,new_size:usize)->*mut u8 {
        if !ACTIVE.load(SeqCst) { return unsafe { System.realloc(ptr,layout,new_size) }; }
        attempt(2,new_size);
        // Failure retains the original allocation, pointer, Layout and contents.
        if FAIL_REALLOC.swap(false,SeqCst) { add(4,1);return std::ptr::null_mut(); }
        let next=unsafe { System.realloc(ptr,layout,new_size) };
        if next.is_null() { add(4,1); } else { subtract(layout.size());success(next,new_size,layout.align()); }
        next
    }
    unsafe fn dealloc(&self,ptr:*mut u8,layout:Layout) {
        if ACTIVE.load(SeqCst) { add(3,1);subtract(layout.size()); }
        unsafe { System.dealloc(ptr,layout) };
    }
}
pub fn begin(fail_alloc:bool,fail_realloc:bool) {
    assert!(!ACTIVE.load(SeqCst),"nested measurement");
    for n in &COUNTERS { n.store(0,SeqCst); }
    FIRST_PTR.store(0,SeqCst);FIRST_SIZE.store(0,SeqCst);FIRST_ALIGN.store(0,SeqCst);FIRST_USABLE.store(usize::MAX,SeqCst);
    FAIL_ALLOC.store(fail_alloc,SeqCst);FAIL_REALLOC.store(fail_realloc,SeqCst);
    ACTIVE.store(true,SeqCst);
}
pub fn finish()->Snapshot {
    ACTIVE.store(false,SeqCst);FAIL_ALLOC.store(false,SeqCst);FAIL_REALLOC.store(false,SeqCst);
    snapshot()
}
pub fn snapshot()->Snapshot { Snapshot {counts:COUNTERS.each_ref().map(|n|n.load(SeqCst)),
    first:[FIRST_PTR.load(SeqCst),FIRST_SIZE.load(SeqCst),FIRST_ALIGN.load(SeqCst)],usable:if FIRST_PTR.load(SeqCst)==0 {0}else{FIRST_USABLE.load(SeqCst)}} }
// Re-enable only to measure destruction of the same retained successful output.
pub fn resume_drop() { assert!(!ACTIVE.swap(true,SeqCst)); }

#[cfg(all(target_os="linux",target_env="gnu",target_arch="x86_64"))]
unsafe extern "C" { fn malloc_usable_size(ptr:*mut std::ffi::c_void)->usize; }
pub fn output_usable(output:&Vec<u8>,scope:Snapshot)->Option<usize> {
    if output.capacity()==0 { return Some(0); }
    if scope.counts[0]!=1 || scope.counts[1]!=0 || scope.counts[2]!=0 || scope.counts[4]!=0
        || scope.first!=[output.as_ptr() as usize,output.capacity(),1] { return None; }
    #[cfg(all(target_os="linux",target_env="gnu",target_arch="x86_64"))]
    {
        // System allocated this live align1 Vec; exact pointer/Layout proven above.
        Some(unsafe { malloc_usable_size(output.as_ptr().cast_mut().cast()) })
    }
    #[cfg(not(all(target_os="linux",target_env="gnu",target_arch="x86_64")))]
    { None }
}
