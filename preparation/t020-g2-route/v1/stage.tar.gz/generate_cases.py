"""Literal Rust expectations from frozen manifests; no product or decoder import."""
from pathlib import Path
import json,binascii
R=Path(__file__).resolve().parent
m=json.loads((R/'frozen/inputs.json').read_text())
classes={'Success':0,'WorkLimitPartial':1,'WorkLimitBeforeOutput':1,'DecodeRejected':2,
'TruncatedStream':3,'OutputExceedsDeclared':4,'TrailingCompressedBytes':6,'DecodedSizeMismatch':7,
'CrcMismatch':8,'EnvelopeCompressedLimit':9,'DecodedLimit':10,'UnsupportedFlags':12,
'UnsupportedMethod':13,'EnvelopeDisagreement':14}
rows=[]
for old,cases in [(True,m['old_cases']),(False,m['new_cases'])]:
 for c in cases:
  expected=c['expected_outcome'] if old else c['expected']
  name=('old-' if old else '')+c['name']
  raw=('old-'+Path(c['raw_file']).name) if old else Path(c['files']['raw']['path']).name
  archive=('old-'+Path(c['zip_file']).name) if old else Path(c['files']['zip']['path']).name
  zhash=c['zip_sha256'] if old else c['files']['zip']['sha256']
  o=c['declared_output_bytes'] if old else c['declared']
  outlen=c['expected_output_bytes'] if old else c['authored_output_length']
  digest=c['expected_output_sha256'] if old else c['authored_output_sha256']
  pre=expected in ('EnvelopeCompressedLimit','DecodedLimit','UnsupportedFlags','UnsupportedMethod','EnvelopeDisagreement')
  private=1 if expected=='WorkLimitPartial' else 2 if expected=='WorkLimitBeforeOutput' else 0
  mandatory=(not old) or c['name'] in m['expected_mandatory_old_successes']
  vals=dict(id=len(rows),name=name,raw=raw,archive=archive,declared=o,expected=classes[expected],
            output_len=outlen,digest=list(bytes.fromhex(digest)),zip_digest=list(bytes.fromhex(zhash)),raw_digest=list(bytes.fromhex(c['raw_sha256'] if old else c['files']['raw']['sha256'])),
            raw_len=c['raw_bytes'] if old else c['files']['raw']['bytes'],consumed=3 if expected=='TrailingCompressedBytes' else (c['raw_bytes'] if old else c['files']['raw']['bytes']),claimed_crc=int(c['claimed_crc32'] if old else c['crc32'],16),actual_crc=binascii.crc32(bytes.fromhex(c['expected_output_hex']) if old else b'A'*c['authored_output_length']),flags_value=int.from_bytes((Path(m['old_packet'])/c['zip_file']).read_bytes()[c['central'][0]+8:c['central'][0]+10],'little') if old else 0,precondition=pre,allow_worklimit=old and not mandatory and not pre,private=private,
            old=old,central=c['central'][0],payload=c['compressed'][0])
  rows.append(vals)
lines=['// Generated only from frozen inputs.json; expectations never observed from candidate.\n',
'''#[derive(Clone, Copy)]
pub struct Case { pub id:usize,pub name:&'static str,pub raw:&'static str,pub archive:&'static str,
 pub declared:usize,pub expected:u64,pub output_len:usize,pub digest:[u8;32],pub zip_digest:[u8;32],pub raw_digest:[u8;32],
 pub raw_len:usize,pub consumed:usize,pub claimed_crc:u32,pub actual_crc:u32,pub flags_value:u16,pub precondition:bool,pub allow_worklimit:bool,pub private:u8,pub old:bool,pub central:usize,pub payload:usize }
pub static CASES:&[Case]=&[\n''']
for c in rows:
 fields=[]
 for k,v in c.items():
  value=json.dumps(v) if not isinstance(v,bool) else str(v).lower()
  fields.append(k+':'+value)
 lines.append(' Case {'+','.join(fields)+'},\n')
lines.append('];\n')
(R/'src/cases.rs').write_text(''.join(lines))
(R/'evidence/CASE-RECORDS.json').write_text(json.dumps(rows,indent=2)+'\n')
print('literal cases',len(rows))
