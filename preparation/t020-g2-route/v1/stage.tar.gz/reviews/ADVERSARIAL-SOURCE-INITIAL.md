# T020 G2 staged-source adversarial review — initial

2026-10-14. Same reviewer `/root/g2_adversarial`. Source/graph review only.
No Cargo, compiler, native test/runtime, candidate decoder/compressor or machine
code simulation was executed. This report is the only reviewer-written file.

## Exact reviewed artifact and data checks

SOURCE-HASHES.json SHA256
`c7e73edfe0673fb94a172500dd1e386ed8fe58987acd622f5e7d7e332358cddf`.
Independently verified all607 actual file digests. Read actual accepted and
changed diagnostic source, README, execution-route/PROPOSAL.md, private wrapper,
shared-extraction/diagnostic patches, allocator, main/receipt/supervisor/case
bindings, manifests/locks and graph metadata.

Permitted `python3 check_stage.py`: PASS source/data only, baseline145,
stored_fixture_cases108, cases125=old90+new35, registry11, lock13;
Cargo resolution/compiler/native runtime all false. Also independently parsed
all11 preserved registry archive Cargo manifests and compared complete package,
normal/build/target dependencies and features to GRAPH-AUDIT.json; verified
archive/build-script hashes and absence of C/C++ source suffixes. These are
source/graph-data checks, not Cargo acceptance or linked-graph evidence.

## Verdict: REVISE two protocol details before source readiness

### S1 — P2: bound and reuse proc observation storage

src/main.rs proc_memory currently uses std::fs::read_to_string on every warmup,
baseline and after-operation observation. The frozen HARNESS requires proc
reads/receipt formatting outside the allocator window in bounded preallocated
storage and fixed reader storage warmed before baseline. Fresh String reads are
unbounded and can add observer allocations/physical peaks after the baseline;
they do not meet that source protocol even though measurements remain empirical.

Use a fixed bounded buffer/checked full read for /proc/self/status, reject
truncation/overflow/missing EOF and malformed units, and reuse or otherwise
explicitly bound the observer storage. Keep observations outside the active
allocator scope and preserve current strict VmRSS/VmHWM unit/overflow checks.
This does not ask for a new parsing dependency or change to numerical ceilings.

### S2 — P2: verify and record the downward guard spans

src/main.rs stack_mapping currently accepts an inaccessible mapping adjacent to
either end of the stack RW mapping, then returns only the two sizes. On the
sole admitted-proposal x86_64 executor the stack grows downward, so an upper-only
guard is not evidence of an overflow guard. The frozen HARNESS also explicitly
requires recording actual stack address/span and guard span; current receipts
retain lengths only, not addresses or a linked map identity.

Require an inaccessible lower guard ending exactly at stack start for this
executor, and retain sufficient span/address evidence in the fixed receipt or
a bounded linked map record. For example the currently free word63 can store
stack start, with existing stack/guard lengths deriving both complete adjacent
spans after checked arithmetic. Preserve the verified map for both candidate
and negative-control paths. A fatal stack-control signal corroborates this
mapping; it does not replace direction/span proof. Unknown arrangements stay
HOLD, rather than generalized to another platform.

## Early findings resolved in this frozen source

- Successful Vec remains alive through usable-size and HWM observation, followed
  by explicit measured drop. Error phases/counters and literal CRC/count/error
  fields are now checked; new mandatory outcomes remain strict.
- Negative-control whole4096-byte object escapes through black_box both before
  and after recursion; emitted frame retention remains a required compile gate.
- Diagnostic prefix13 slow and14/15 fast-entry assertions are explicit; full
  fast apply_match(258,1,out_pos4) remains required. Instrumented copies remain
  distinct from accepted snapshots/physical metrics.
- OS cleanup/status is preserved before pipe joins; captures drain with fixed
  retained bounds and errors fail the cohort. Spawn/try_wait/kill/reap failures
  cannot silently continue. Reap/join hangs are honestly HOLD.
- Child env_clear plus LANG/LC_ALL prevents inherited loader/allocator variables.
  /etc/ld.so.preload, actual mapped glibc/loader/IFUNC identities and unsafe
  malloc_usable_size binding still require root preflight; env clearing alone
  is correctly not promoted to proof.
- GlobalAlloc hooks are atomic/nonallocating. Failed realloc leaves old pointer,
  Layout and contents intact; K6 verifies this before deallocation. malloc_usable_size
  only observes non-null live System align1 pointers, and retained Vec observation
  additionally checks exact pointer/capacity/alignment and one-allocation history.
  Under the later established allocator binding, no dangling/failed/foreign/
  zero-capacity pointer observation was found in source.
- Shared selected-envelope extraction preserves original method0 body except
  explicit method/size/cap selection and carries accumulated work into its
  unchanged payload debit; CRC body is moved unchanged. All108 stored cases and
  their sources remain exact. Their actual execution still requires a grant.

Stage readiness does not admit Linux route/workflow/publication, compilation,
calibration or candidate execution. Root-controlled admission/executor files are
absent, manual lock acceptance is untested, complete compiled stack/copy/helper
coverage and physical/panic outcomes remain UNKNOWN. Full compiled equivalence,
HDIST31/32, descriptors and semantic/platform parity are not established.

Skipped compilation and runtime. Resolve S1/S2; allocator binding, stack and
physical/panic acceptance remain gated and unverified.
