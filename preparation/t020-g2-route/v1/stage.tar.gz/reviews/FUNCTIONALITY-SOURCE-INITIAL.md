# T020 G2 correctness/functionality staged-source review — initial

Reviewer: `/root/g2_functionality`, 2026-10-14. Source/data review only.

Verdict: **HOLD for the measurement and calibration-binding repairs below.**
The wrapper, shared extraction, literal fixtures and proposed manual dependency
graph are coherent on static review. This is neither compilation approval nor a
G2 runtime verdict; root must separately admit exact Linux/toolchain/executor,
compilation, controls, compiled stack assessment and candidate execution.

## Exact reviewed bytes and checks

Verified all **607** files against SOURCE-HASHES.json, SHA256
`c7e73edfe0673fb94a172500dd1e386ed8fe58987acd622f5e7d7e332358cddf`.
Ran only `python3 check_stage.py`: **PASS source/data only**,145 baseline files,
108 stored fixture cases,125 staged cases(90 old+35 new),11 registry archives,
13 packages per manual lock; cargo_resolution/compiler/native_runtime false.

Own independent static/data checks:

- Parsed all125 literal Rust Case rows as data and matched every row to
  CASE-RECORDS, then independently to frozen old/new fixture metadata and ZIP
  headers. Verified outcome mapping, mandatory-success/WorkLimit permission,
  precondition exclusions, private-output modes, declarations/output hashes,
  raw/archive digests, payload/central positions, claimed/actual CRCs, flags and
  trailing consumed3/total fields. No Rust or DEFLATE was evaluated.
- Reconstructed all four baseline and both diagnostic unified diff bodies and
  matched their saved evidence. The selected-envelope extraction matches the
  frozen stored body exactly except the four approved method/size/cap choices;
  original CRC source is unchanged. Stored caller retains selected.work and
  its final payload debit before CRC, with existing borrowed output semantics.
- Accepted core/shared/output_buffer equal the frozen meter snapshots. Parent
  equals the exact snapshot prefix plus wrapper include; diagnostic probes and
  layout helper are separate bytes/artifacts and cannot supply accepted physical
  measurements. Diagnostic source differs as documented.
- Independently read all11 registry archives as data and verified checksum,
  normalized Cargo package/dependency/target/feature metadata, build-script
  hashes and absence of C/C++ source files against GRAPH-AUDIT. Both13-package
  manual locks have correct distinct staged-package names/edges and the pinned
  registry records. Selected features remain sha2 std/force-soft and adler2
  no defaults/features. Optional sha2-asm/rustc-workspace/other platform paths
  are not newly selected. No Cargo resolution or linked-reachability claim.

## Actionable findings

1. **[P1] Use bounded, preopened observation readers.** main.rs proc_memory uses
   read_to_string each time, including after the measured wrapper while returned
   output is alive. That observer allocates and changes the process physical
   peak being observed. stack_mapping also reads an unbounded String and grows a
   Vec despite the frozen bounded observation design. Replace these readers with
   reusable preopened/fixed storage and strict read/parse bounds; overflow,
   unexpected units, missing/duplicate fields or unsupported layout must HOLD.
   Observer setup must precede baseline and allocator windows, and no observer
   allocation should alter the post-operation RSS observation.

2. **[P1] Corroborate the lower stack guard specifically and retain its address.**
   stack_mapping accepts either b==start or a==end. On this admitted downward-
   growing x86_64 stack, an inaccessible mapping above the stack does not guard
   overflow below it. Require the guard whose end equals the RW stack start,
   retain stack start/bounds in the fixed receipt, and keep the exact1MiB mapping
   and minimum4096-byte guard checks. The separate fatal control must use that
   verified arrangement. No runtime small-stack pass replaces compiled bounds.

3. **[P1] Bind successful calibration to its complete admitted context.** The
   current CALIBRATION-profile.ok contains only child hash and profile. admitted
   checks those two fields, so a calibration receipt from another role/source/
   graph/executor/admission context can be reused for the same child binary.
   Freeze and verify role, source, graph, executor and the exact calibration-
   admission file hash in the .ok receipt, alongside child/profile. Keep accepted
   and diagnostic identities separate and require the current execution context
   to agree before any candidate child starts.

These findings agree with the architect/adversarial readbacks communicated by
the owner; they are present in the actual frozen source reviewed here.

## Early repairs rechecked in actual frozen source

- error_matches now checks exact CRC expected/actual, exact trailing consumed/
  total, flag value and central phase, method value/local phase and the flags
  disagreement offset/field. Decoded/ compressed caps and WorkLimit aliases keep
  their distinct offsets/static labels.
- Wrapper checks exact envelope/reserve/meter/init/raw/CRC/publication phases,
  requested/live/peak allocation counts and error drops. Success holds the Vec
  through usable/RSS observations, then measures its explicit drop. Core-only
  scope excludes setup/output destruction and checks all heap counts zero.
- K4/K5 emit explicit CoreAllocation/Panic outcomes and FAIL/exit70; K0-K6 exact
  counts, failed-realloc ownership/layout/content and phase precedence are
  coherent. Prefix14 requires no fast entry, prefixes15/16 require a fast entry,
  and the full stream requires fast match258/distance1/out_pos4.
- Supervisor clears inherited child environment, retains OS cleanup/status
  evidence before joins and rejects OS/capture failures. Hang/reap ambiguity is
  still explicitly HOLD; no hard-completion proof is claimed from this code.
- The unsafe usable-size call in success runs only after a non-null System
  allocation at align1, while that pointer is live. Returned Vec observation
  checks exact pointer/size/alignment and skips zero capacity. Realloc failure
  preserves the old allocation; snapshots use cached usable observations after
  free, never dereference freed pointers. Actual System/glibc/loader binding is
  still a mandatory future executor gate, not established by comments.
- My first message about empty output used stale draft assumptions. The frozen
  snapshot normalizes usable to0 when FIRST_PTR==0; output_usable(empty)=Some0,
  so the frozen empty-success equality is coherent. That finding is withdrawn.

Not checked: no Rust/Cargo/fmt/clippy/native tests, compiler, decoder, calibration,
stack control, candidate execution, workflow publication or dispatch ran. Manual
locks may still be rejected by --locked; source review does not prove compilation,
physical bounds, compiled equivalence, stored108 runtime preservation, product
composition, T020 completion or any semantic/platform parity.
