mod metrics;
mod cases;
mod wire;
use std::io::{Write,Read,Seek};
use std::path::PathBuf;
use ktlsp_artifacts as artifacts;
use sha2::{Digest,Sha256};
use cases::Case;
use wire::*;
#[global_allocator]
static ALLOCATOR:metrics::MeteredSystem=metrics::MeteredSystem;
const DIAGNOSTIC:bool=false;

fn digest(data:&[u8])->[u8;32] { Sha256::digest(data).into() }
fn touch(data:&mut [u8]) {
    for byte in data.iter_mut().step_by(4096) {
        // Commit setup pages before RSS baseline; all setup precedes scope.
        unsafe { std::ptr::write_volatile(byte,*byte) };
    }
}
struct ProcReader {file:std::fs::File,buffer:[u8;16384]}
impl ProcReader {
    fn new()->std::io::Result<Self> {Ok(Self {file:std::fs::File::open("/proc/self/status")?,buffer:[0;16384]})}
    fn memory(&mut self)->Option<(u64,u64)> {
        self.file.rewind().ok()?;
        let n=read_bounded(&mut self.file,&mut self.buffer)?;
        parse_memory(&self.buffer[..n])
    }
}
fn parse_memory(bytes:&[u8])->Option<(u64,u64)> {
    let text=std::str::from_utf8(bytes).ok()?;
    let mut rss=None;let mut peak=None;
    for line in text.lines() {
        let mut parts=line.split_whitespace();let key=parts.next()?;
        if key=="VmRSS:" || key=="VmHWM:" {
            let value=parts.next()?.parse::<u64>().ok()?.checked_mul(1024)?;
            if parts.next()!=Some("kB") || parts.next().is_some(){return None;}
            if key=="VmRSS:" {if rss.replace(value).is_some(){return None;}}
            else if peak.replace(value).is_some(){return None;}
        }
    }
    Some((rss?,peak?))
}

fn read_bounded(reader:&mut impl Read,buffer:&mut [u8])->Option<usize> {
    let mut used=0;
    while used<buffer.len() {let n=reader.read(&mut buffer[used..]).ok()?;if n==0{return Some(used);}used+=n;}
    let mut extra=[0u8;1];(reader.read(&mut extra).ok()?==0).then_some(used)
}
fn map_line(line:&str)->Option<(usize,usize,&str)> {
    let mut p=line.split_whitespace();let span=p.next()?;let flags=p.next()?;
    let (a,b)=span.split_once('-')?;
    Some((usize::from_str_radix(a,16).ok()?,usize::from_str_radix(b,16).ok()?,flags))
}
fn stack_mapping(address:usize)->Option<(usize,usize,usize)> {
    let mut file=std::fs::File::open("/proc/thread-self/maps").ok()?;
    let mut buffer=[0u8;65536];let n=read_bounded(&mut file,&mut buffer)?;
    let text=std::str::from_utf8(&buffer[..n]).ok()?;
    if !text.lines().all(|line|map_line(line).is_some()){return None;}
    let (start,end,flags)=text.lines().filter_map(map_line).find(|&(a,b,_)|a<=address && address<b)?;
    if flags!="rw-p" || end.checked_sub(start)?!=1_048_576{return None;}
    // Sole admitted x86_64 executor grows downward: guard must meet lower edge.
    let (guard_start,guard_end,_)=text.lines().filter_map(map_line).find(|&(_,b,f)|b==start && f=="---p")?;
    let guard=guard_end.checked_sub(guard_start)?;
    (guard>=4096).then_some((end-start,guard,start))
}
fn send(r:&Receipt) { std::io::stdout().lock().write_all(&encode(r)).expect("receipt write"); }
fn base(id:usize,mode:u64,stack:(usize,usize,usize))->Receipt {
    let mut r=[0;WORDS];r[0]=MAGIC;r[1]=id as u64;r[2]=mode;r[3]=FAIL;
    r[13]=stack.0 as u64;r[14]=stack.1 as u64;r[58]=std::process::id() as u64;r[59]=DIAGNOSTIC as u64;r[63]=stack.2 as u64;r
}
fn copy_stats(r:&mut Receipt,s:metrics::Snapshot) {
    r[15..26].copy_from_slice(&s.counts);r[10]=s.usable as u64;
    for i in 0..3 {r[26+i]=s.first[i] as u64;}
}
fn phases(r:&mut Receipt)->artifacts::ProbePhases {
    let p=artifacts::__g2_phases();
    r[30..37].copy_from_slice(&[p.envelope as u64,p.reserve as u64,p.meter as u64,
        p.init as u64,p.raw as u64,p.crc as u64,p.publish as u64]);p
}
fn memory_ok(r:&mut Receipt,baseline:u64,observer:&mut ProcReader)->bool {
    let Some((_,h))=observer.memory() else{return false;};r[11]=baseline;r[12]=h;
    h<=134_217_728 && h.saturating_sub(baseline)<=33_554_432
}
fn hash_receipt(r:&mut Receipt,hash:[u8;32]) {
    for (i,chunk) in hash.chunks_exact(8).enumerate() {r[38+i]=u64::from_le_bytes(chunk.try_into().unwrap());}
}
fn error_matches(e:&artifacts::ZipDeflateError,c:&Case)->(u64,bool) {
    use artifacts::{ZipDeflateError as E,ZipStoredError as S,ZipIndexError as I};
    let p=c.payload;
    let (kind,valid)=match e {
        E::WorkLimit{offset}=>(WORK_LIMIT,*offset==p),
        E::DecodeRejected{offset}=>(DECODE_REJECTED,*offset==p),
        E::TruncatedStream{offset}=>(TRUNCATED,*offset==p),
        E::OutputExceedsDeclared{offset}=>(OUTPUT_EXCEEDS,*offset==p),
        E::DecoderInvariant{offset}=>(INVARIANT,*offset==p),
        E::TrailingCompressedBytes{offset,consumed,total}=>(TRAILING,*offset==p && *consumed==c.consumed && *total==c.raw_len),
        E::DecodedSizeMismatch{offset,expected,actual}=>(SIZE_MISMATCH,*offset==p && *expected==c.declared && *actual==c.output_len),
        E::CrcMismatch{offset,expected,actual}=>(CRC_MISMATCH,*offset==p && *expected==c.claimed_crc && *actual==c.actual_crc),
        E::DecodedLimit{offset,limit}=>(DECODED_LIMIT,*offset==22 && *limit==8_388_608),
        E::Allocation{offset}=>(ALLOCATION,*offset==p),
        E::Envelope(S::Structure(I::Limit{offset,field,limit}))=>(COMPRESSED_LIMIT,
            *offset==p && *field=="deflated compressed bytes" && *limit==8_388_608),
        E::Envelope(S::Structure(I::UnsupportedFlags{offset,flags}))=>(FLAGS,*offset==c.central+8 && *flags==c.flags_value),
        E::Envelope(S::Structure(I::UnsupportedMethod{offset,method}))=>(METHOD,*offset==8 && *method==0),
        E::Envelope(S::Disagreement{offset,field})=>(DISAGREEMENT,*offset==6 && *field=="flags"),
        _=>(OTHER_ENVELOPE,false),
    };
    (kind,valid)
}
fn diagnostics(r:&mut Receipt,c:&Case)->bool {
    let report=artifacts::__g2_diagnostics();
    if !DIAGNOSTIC {return report.is_none();}
    let Some(d)=report else{return false;};
    for i in 0..6 {r[42+i]=d.layouts[i] as u64;}
    r[48]=d.guards as u64;for i in 0..3 {r[49+i]=d.first_guard[i] as u64;}
    r[52]=d.fast_entries as u64;r[53]=d.fast_matches as u64;
    for i in 0..3 {r[54+i]=d.first_match[i] as u64;}r[57]=d.overflow as u64;
    let expected=match c.name {
        "fast-declared326"=>[5,70,326],"fast-prefix14"=>[5,13,326],
        "fast-prefix15"=>[5,14,326],"fast-prefix16"=>[5,15,326],_=>return false,
    };
    !d.overflow && d.guards>0 && d.first_guard==expected &&
        (c.name!="fast-declared326" || (d.fast_entries>0 && d.fast_matches>0 && d.first_match==[258,1,4])) &&
        (c.name!="fast-prefix14" || d.fast_entries==0) &&
        (!matches!(c.name,"fast-prefix15"|"fast-prefix16") || d.fast_entries>0)
}
fn measured(c:Case,mode:u64,stack:(usize,usize,usize),root:PathBuf)->Receipt {
    let mut r=base(c.id,mode,stack);
    let mut archive=std::fs::read(root.join("inputs").join(c.archive)).expect("fixture");touch(&mut archive);
    assert_eq!(digest(&archive),c.zip_digest,"frozen archive hash");
    let provenance=artifacts::Provenance {coordinate:artifacts::Coordinate::new("g2","case","1",None,"zip").unwrap(),
        repository_root:PathBuf::from("/g2"),artifact_path:PathBuf::from("/g2/case"),
        byte_length:archive.len(),checksum:artifacts::ChecksumStatus::Unverified};
    let verified=artifacts::verify_sha256(artifacts::Artifact {bytes:archive,provenance},c.zip_digest).unwrap();
    let index=artifacts::index_zip_directory(&verified).unwrap();
    let before=*verified.digest();
    let mut raw=std::fs::read(root.join("inputs").join(c.raw)).expect("raw fixture");touch(&mut raw);assert_eq!(digest(&raw),c.raw_digest,"frozen raw hash");
    let mut output=if mode==1 {vec![0;c.declared]} else {Vec::new()};touch(&mut output);
    // Warm proc readers, page touches and thread startup before the scope baseline.
    let mut observer=ProcReader::new().expect("proc reader");
    let _=observer.memory().expect("proc memory warmup");
    let baseline=observer.memory().expect("proc memory baseline").0;
    artifacts::__g2_phase_reset();
    r[8]=c.declared as u64;
    metrics::begin(mode==2,false);
    if mode==1 {
        assert!(!c.precondition,"core precondition bypass");
        let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||artifacts::__g2_core(&raw,&mut output)));
        let s=metrics::finish();copy_stats(&mut r,s);
        let mut ok=s.counts.iter().all(|&n|n==0) && s.first==[0;3];
        match result {
            Err(_)=>{r[5]=1;ok=false;},
            Ok(core)=>{
                r[4]=core.outcome as u64;r[6]=core.consumed as u64;r[7]=core.written as u64;
                if r[4]==WORK_LIMIT {
                    ok &= c.expected==WORK_LIMIT || c.allow_worklimit;
                    if c.private==1 {
                        let cut=output.iter().take_while(|&&b|b==b'A').count();
                        r[37]=(cut>0 && cut<output.len() && output[cut..].iter().all(|&b|b==0)) as u64;
                        ok &= r[37]==1;
                    } else if c.private==2 {r[37]=output.iter().all(|&b|b==0) as u64;ok &= r[37]==1;}
                } else {
                    let expected=match c.expected {TRAILING|SIZE_MISMATCH|CRC_MISMATCH=>SUCCESS,n=>n};
                    ok &= r[4]==expected && core.consumed<=raw.len() && core.written<=output.len();
                    if core.outcome==artifacts::ProbeOutcome::Done && core.consumed<=raw.len() && core.written<=output.len() {
                        let bytes=&output[..core.written];let h=digest(bytes);hash_receipt(&mut r,h);
                        ok &= core.written==c.output_len && h==c.digest;
                        ok &= core.consumed==c.consumed;
                    }
                }
            }
        }
        let p=phases(&mut r);ok &= p.envelope==0 && p.reserve==0 && p.init==0 && p.meter==1 && p.raw==1 && p.crc==0 && p.publish==0;
        ok &= memory_ok(&mut r,baseline,&mut observer) && diagnostics(&mut r,&c);
        ok &= *verified.digest()==before && digest(verified.bytes())==before;
        r[3]=if ok {PASS}else{FAIL};
    } else {
        let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||index.deflated_payload(0)));
        let s=metrics::finish();copy_stats(&mut r,s);let p=phases(&mut r);
        let mut ok=s.counts[2]==0 && s.counts[10]==0;let mut memory_observed=false;
        match result {
            Err(_)=>{r[5]=1;ok=false;},
            Ok(Err(error))=>{
                let (kind,valid)=error_matches(&error,&c);r[4]=kind;
                ok &= valid && s.counts[7]==0 && p.publish==0;
                if mode==2 {ok &= kind==ALLOCATION && s.counts[4]==1 && p.reserve==1 && p.meter==0 && p.init==0 && p.raw==0;}
                else {ok &= kind==c.expected || (kind==WORK_LIMIT && c.allow_worklimit);}
            }
            Ok(Ok(bytes))=>{
                r[4]=SUCCESS;r[9]=bytes.capacity() as u64;
                let usable=metrics::output_usable(&bytes,s);r[10]=usable.unwrap_or(usize::MAX) as u64;
                let h=digest(&bytes);hash_receipt(&mut r,h);
                ok &= mode==0 && c.expected==SUCCESS && bytes.len()==c.output_len && h==c.digest && p.publish==1;
                ok &= bytes.capacity()==c.declared && s.counts[7]==c.declared as u64 && usable==Some(s.usable) && usable.is_some_and(|n|n>=c.declared && n<=c.declared+8192);
                ok &= memory_ok(&mut r,baseline,&mut observer);memory_observed=true;
                metrics::resume_drop();drop(bytes);let dropped=metrics::finish();r[29]=dropped.counts[7];r[61]=dropped.counts[3];r[62]=dropped.counts[10];ok &= r[29]==0 && dropped.counts[10]==0;
            }
        }
        ok &= p.envelope==1 && p.reserve==if c.precondition {0}else{(c.declared>0) as usize};
        ok &= p.crc==if matches!(r[4],SUCCESS|CRC_MISMATCH) {1}else{0};
        ok &= p.publish==if r[4]==SUCCESS {1}else{0};
        if c.precondition {ok &= s.counts.iter().all(|&n|n==0) && p.reserve==0 && p.meter==0 && p.init==0 && p.raw==0;}
        else {
            let expected=(c.declared>0) as u64;
            ok &= s.counts[0]==expected && s.counts[1]==0 && s.counts[5]==c.declared as u64 && s.counts[8]==if mode==2 {0}else{c.declared as u64};
            ok &= s.counts[6]==if mode==2 {0}else{c.declared as u64};
            ok &= s.counts[3]==if mode==2 || r[4]==SUCCESS || c.declared==0 {0}else{1};
            if mode!=2 {ok &= (c.declared==0 || (s.usable>=c.declared && s.usable<=c.declared+8192)) && s.counts[4]==0 && p.meter==1 && p.init==1 && p.raw==1;}
        }
        if !memory_observed {ok &= memory_ok(&mut r,baseline,&mut observer);}
        ok &= diagnostics(&mut r,&c);
        ok &= *verified.digest()==before && digest(verified.bytes())==before;
        r[3]=if ok {PASS}else{FAIL};
    }
    r
}
fn control(id:usize,stack:(usize,usize,usize))->Receipt {
    use std::alloc::{alloc,alloc_zeroed,dealloc,realloc,Layout};
    let mut r=base(id,10,stack);let mut preserved=true;
    let a=Layout::from_size_align(16,8).unwrap();let b=Layout::from_size_align(32,8).unwrap();
    metrics::begin(id==3,id==6);
    let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||unsafe {
        match id {
            0=>{},
            1=>{let p=alloc(a);let q=alloc_zeroed(b);assert!(!p.is_null() && !q.is_null());
                std::hint::black_box(p);std::hint::black_box(q);dealloc(p,a);dealloc(q,b);},
            2|6=>{let p=alloc(a);assert!(!p.is_null());for i in 0..16 {p.add(i).write_volatile(0xa5);}
                let q=realloc(p,a,48);
                if id==6 {assert!(q.is_null());for i in 0..16 {preserved &= p.add(i).read_volatile()==0xa5;}dealloc(p,a);}
                else {assert!(!q.is_null());for i in 0..16 {preserved &= q.add(i).read_volatile()==0xa5;}dealloc(q,Layout::from_size_align(48,8).unwrap());}},
            3=>{let p=alloc(Layout::from_size_align(16,1).unwrap());assert!(p.is_null());},
            4=>{let l=Layout::from_size_align(8,1).unwrap();let p=alloc(l);assert!(!p.is_null());p.write_volatile(1);dealloc(p,l);},
            5=>panic!("G2 deliberate panic"),
            _=>panic!("unknown control"),
        }
    }));
    let s=metrics::finish();copy_stats(&mut r,s);r[5]=result.is_err() as u64;
    let c=s.counts;
    let mut expected=[0u64;11];
    match id {
        0=>{},
        1=>{expected=[1,1,0,2,0,48,48,0,48,48,0];},
        2=>{expected=[1,0,1,1,0,64,64,0,48,64,0];},
        3=>{expected=[1,0,0,0,1,16,0,0,0,16,0];},
        4=>{expected=[1,0,0,1,0,8,8,0,8,8,0];},
        5=>{},
        6=>{expected=[1,0,1,1,1,64,16,0,16,64,0];},
        _=>{},
    }
    let ok=if id==5 {r[5]==1} else {result.is_ok() && c==expected && preserved};
    r[37]=preserved as u64;
    r[3]=if ok && id!=4 && id!=5 {PASS}else{FAIL};
    r[4]=match id {3=>ALLOCATION,4=>16,5=>17,_=>SUCCESS};
    // K4/K5 intentionally produce FAIL; parent verifies their literal evidence.
    r[60]=ok as u64;
    r
}
#[inline(never)]
fn consume_stack(depth:usize)->u8 {
    let mut page=[0u8;4096];
    unsafe {page.as_mut_ptr().write_volatile(depth as u8);page.as_mut_ptr().add(4095).write_volatile(1);}
    std::hint::black_box(&mut page);
    let inner=if depth==0 {0}else{consume_stack(depth-1)};
    std::hint::black_box(&page);
    inner ^ unsafe {page.as_ptr().read_volatile()} ^ std::hint::black_box(page[4095])
}
fn thread_run(args:Vec<String>,root:PathBuf)->Receipt {
    let anchor=0u8;let stack=stack_mapping(std::hint::black_box(&anchor) as *const u8 as usize).expect("guarded 1MiB stack");
    if args[1]=="stack-negative" {
        std::io::stdout().lock().write_all(b"G2READY\n").unwrap();
        std::hint::black_box(consume_stack(300));
        panic!("stack negative control returned");
    }
    if args[1]=="control" {return control(args[2].parse().expect("control id"),stack);}
    let id:usize=args[2].parse().expect("case id");let c=*cases::CASES.get(id).expect("case id range");
    let mode=match args[1].as_str() {"wrapper"=>0,"core"=>1,"allocation-failure"=>2,_=>panic!("mode")};
    measured(c,mode,stack,root)
}
fn main() {
    if !cfg!(all(target_os="linux",target_arch="x86_64",target_env="gnu")) {std::process::exit(70);}
    std::panic::set_hook(Box::new(|_|{}));
    let args:Vec<String>=std::env::args().collect();
    if args.len()!=4 {std::process::exit(70);}
    let root=PathBuf::from(&args[3]);
    let result=std::thread::Builder::new().stack_size(1_048_576).spawn(move||thread_run(args,root)).expect("thread spawn").join();
    match result {Ok(r)=>{send(&r);std::process::exit(r[3] as i32);},Err(_)=>std::process::exit(70)}
}

#[cfg(test)]
mod observation_tests {
    use super::*;
    #[test]
    fn bounded_read_requires_complete_eof() {
        let mut buffer=[0u8;4];
        assert_eq!(read_bounded(&mut std::io::Cursor::new(b"1234"),&mut buffer),Some(4));
        assert_eq!(read_bounded(&mut std::io::Cursor::new(b"12345"),&mut buffer),None);
    }
    #[test]
    fn memory_fields_reject_missing_duplicate_wrong_unit_and_overflow() {
        assert_eq!(parse_memory(b"VmRSS: 2 kB\nVmHWM: 3 kB\n"),Some((2048,3072)));
        for input in [b"VmRSS: 2 kB\n".as_slice(),b"VmRSS: 2 kB\nVmRSS: 2 kB\nVmHWM: 3 kB\n",
            b"VmRSS: 2 MB\nVmHWM: 3 kB\n",b"VmRSS: 18446744073709551615 kB\nVmHWM: 3 kB\n"] {
            assert_eq!(parse_memory(input),None);
        }
    }
}
