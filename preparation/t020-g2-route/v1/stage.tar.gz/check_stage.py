"""Source, lock and fixture checks only. Never invokes native tools or decodes."""
from pathlib import Path
import hashlib,json,tomllib,difflib
R=Path(__file__).resolve().parent
B=Path('/Users/anil/.codex/worktrees/t020-g2-packet/ktlsp/crates/ktlsp-artifacts')
M=Path('/private/tmp/ktlsp-t020-work-meter/preparation/t020-meter')
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 baseline=json.loads((R/'evidence/BASELINE-HASHES.json').read_text())
 assert len(baseline)==145
 assert len(json.loads((R/'artifacts-under-test/tests/fixtures/zip_stored/fixtures.json').read_text())['cases'])==108
 changed={'Cargo.toml','src/lib.rs','src/zip_index.rs','src/zip_stored.rs'}
 for name,digest in baseline.items():
  assert sha((B/name).read_bytes())==digest
  if name not in changed:assert sha((R/'artifacts-under-test'/name).read_bytes())==digest
 for name in ('core','output_buffer','shared'):
  expected=(M/f'proposal/{name}.rs.txt').read_bytes()
  assert (R/f'frozen/{name}.rs.txt').read_bytes()==expected
  assert (R/f'artifacts-under-test/src/zip_deflate_private/{name}.rs').read_bytes()==expected
 parent=(M/'proposal/mod.rs.txt').read_bytes()
 assert (R/'artifacts-under-test/src/zip_deflate_private/mod.rs').read_bytes()==parent+b'\ninclude!("wrapper.rs");\n'
 old=(B/'src/zip_stored.rs').read_text()
 a=old.index('        let entry = self\n');b=old.index('        charge(&mut work, size, MAX_WORK, p, "stored work units")',a)
 body=old[a:b].replace('if entry.method != 0 {','if entry.method != selected_method {').replace('if method != 0 {','if method != selected_method {')
 body=body.replace('if compressed != uncompressed {','if selected_method == 0 && compressed != uncompressed {')
 body=body.replace('limit(size, MAX_PAYLOAD, p, "stored payload bytes")','limit(size, MAX_PAYLOAD, p, if selected_method == 0 { "stored payload bytes" } else { "deflated compressed bytes" })').replace('MAX_PAYLOAD','MAX_SELECTED_PAYLOAD')
 actual=(R/'artifacts-under-test/src/zip_index.rs').read_text()
 start=actual.index('        let entry = self\n',actual.index('fn selected_envelope('))
 assert actual[start:start+len(body)]==body
 crc=old[old.index('fn crc32(bytes: &[u8])'):old.index('\n#[cfg(test)]',old.index('fn crc32(bytes: &[u8])'))]
 assert crc in actual and 'fn crc32(' not in (R/'artifacts-under-test/src/zip_stored.rs').read_text()
 assert 'let mut work = selected.work;' in (R/'artifacts-under-test/src/zip_stored.rs').read_text()
 for name in ('metrics.rs','wire.rs','cases.rs'):
  assert (R/'src'/name).read_bytes()==(R/'diagnostic-copy/src'/name).read_bytes()
 assert (R/'diagnostic-copy/src/main.rs').read_text()==(R/'src/main.rs').read_text().replace('const DIAGNOSTIC:bool=false;','const DIAGNOSTIC:bool=true;')
 assert (R/'supervise.rs').read_bytes()==(R/'diagnostic-copy/supervise.rs').read_bytes()
 manifest=json.loads((R/'frozen/inputs.json').read_text())
 for c in manifest['old_cases']:
  for key in ('raw','zip'):
   f=R/'inputs'/('old-'+Path(c[key+'_file']).name)
   assert sha(f.read_bytes())==c[key+'_sha256']
 for c in manifest['new_cases']:
  for info in c['files'].values():assert sha((R/'inputs'/Path(info['path']).name).read_bytes())==info['sha256']
 cases=json.loads((R/'evidence/CASE-RECORDS.json').read_text());assert len(cases)==125
 rust=(R/'src/cases.rs').read_text();assert sum(line.startswith(' Case {') for line in rust.splitlines())==125
 registry=json.loads((R/'evidence/REGISTRY-RECORDS.json').read_text())
 assert len(registry)==11
 for p in registry:assert sha((R/'dependencies'/f"{p['name']}-{p['version']}.crate").read_bytes())==p['checksum']
 for root,diagnostic in [(R,False),(R/'diagnostic-copy',True)]:
  lock=tomllib.loads((root/'Cargo.lock').read_text());pkgs={p['name']:p for p in lock['package']}
  assert len(pkgs)==13 and lock['version']==4
  for p in registry:assert pkgs[p['name']]==p
  assert all(d in pkgs for p in pkgs.values() for d in p.get('dependencies',[]))
  cargo=tomllib.loads((root/'Cargo.toml').read_text())
  assert cargo['workspace']['resolver']=='3' and cargo['workspace']['package']==dict(version='0.1.0',edition='2024',**{'rust-version':'1.90'})
  for key,level in [('g2-d',0),('g2-r',3)]:
   profile=cargo['profile'][key]
   assert profile['opt-level']==level and profile['panic']=='unwind' and profile['codegen-units']==1 and profile['incremental'] is False and profile['lto'] is False
  dep=tomllib.loads((root/'artifacts-under-test/Cargo.toml').read_text())['dependencies']
  assert dep['adler2']=={'version':'=2.0.1','default-features':False,'features':[]}
  assert dep['sha2']['features']==['std','force-soft']
 # These native outputs/admissions must not exist in SOURCE STAGING phase.
 assert not list(R.rglob('target'))
 assert not list(R.glob('*-ADMISSION-*.txt'))
 assert not (R/'evidence/EXECUTOR-BOUND.json').exists()
 print(json.dumps(dict(status='PASS source/data only',baseline_files=145,stored_fixture_cases=108,
   cases=125,old_cases=90,new_cases=35,registry_packages=11,lock_packages=13,
   cargo_resolution=False,compiler=False,native_runtime=False)))
if __name__=='__main__':main()
