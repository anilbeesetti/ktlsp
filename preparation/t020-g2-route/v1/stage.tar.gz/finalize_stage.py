"""Finish source/graph bindings as data; no Cargo or native execution."""
from pathlib import Path
import json,shutil,hashlib
R=Path(__file__).resolve().parent
manifest='''[workspace]
members = ["artifacts-under-test"]
exclude = ["diagnostic-copy"]
resolver = "3"
[workspace.package]
version = "0.1.0"
edition = "2024"
rust-version = "1.90"
[package]
name = "ktlsp-g2-stage"
version.workspace = true
edition.workspace = true
rust-version.workspace = true
[dependencies]
ktlsp-artifacts = { path = "artifacts-under-test" }
sha2 = { version = "=0.10.9", default-features = false, features = ["std", "force-soft"] }
[[bin]]
name = "g2-child"
path = "src/main.rs"
[[bin]]
name = "g2-supervise"
path = "supervise.rs"
[profile.g2-d]
inherits = "dev"
opt-level = 0
debug-assertions = true
overflow-checks = true
panic = "unwind"
debug = 2
lto = false
codegen-units = 1
incremental = false
[profile.g2-r]
inherits = "release"
opt-level = 3
debug-assertions = false
overflow-checks = false
panic = "unwind"
debug = 2
lto = false
codegen-units = 1
incremental = false
'''
(R/'Cargo.toml').write_text(manifest)
(R/'.cargo').mkdir(exist_ok=True)
(R/'.cargo/config.toml').write_text('[build]\ntarget = "x86_64-unknown-linux-gnu"\nrustflags = ["-Ctarget-cpu=x86-64"]\n')
records=json.loads((R/'evidence/REGISTRY-RECORDS.json').read_text())
def locked(diagnostic=False):
 pkgs=list(records)+[dict(name='ktlsp-artifacts-g2-diagnostic' if diagnostic else 'ktlsp-artifacts',version='0.1.0',dependencies=['adler2','sha2']),
 dict(name='ktlsp-g2-diagnostic' if diagnostic else 'ktlsp-g2-stage',version='0.1.0',dependencies=['ktlsp-artifacts-g2-diagnostic' if diagnostic else 'ktlsp-artifacts','sha2'])]
 out='# Manually staged exact graph data; Cargo resolution NOT performed.\nversion = 4\n'
 for p in sorted(pkgs,key=lambda p:p['name']):
  out+='\n[[package]]\n'
  for k in ('name','version','source','checksum','dependencies'):
   if k in p:out+=k+' = '+json.dumps(p[k])+'\n'
 return out
(R/'Cargo.lock').write_text(locked())
diag=R/'diagnostic-copy';assert not diag.exists()
diag.mkdir();shutil.copytree(R/'artifacts-under-test',diag/'artifacts-under-test')
shutil.copytree(R/'src',diag/'src');shutil.copy2(R/'supervise.rs',diag/'supervise.rs')
shutil.copytree(R/'.cargo',diag/'.cargo')
(diag/'Cargo.toml').write_text(manifest.replace('name = "ktlsp-g2-stage"','name = "ktlsp-g2-diagnostic"').replace('ktlsp-artifacts = { path = "artifacts-under-test" }','ktlsp-artifacts = { package = "ktlsp-artifacts-g2-diagnostic", path = "artifacts-under-test" }'))
p=diag/'artifacts-under-test/Cargo.toml';p.write_text(p.read_text().replace('name = "ktlsp-artifacts"','name = "ktlsp-artifacts-g2-diagnostic"')+'\n[lib]\nname = "ktlsp_artifacts"\n')
(diag/'Cargo.lock').write_text(locked(True))
p=diag/'src/main.rs';p.write_text(p.read_text().replace('const DIAGNOSTIC:bool=false;','const DIAGNOSTIC:bool=true;'))
p=diag/'artifacts-under-test/src/zip_deflate_private/core.rs';s=p.read_text()
anchor='''            DecodeLitlen => generate_state!(state, 'state_machine, meter, {
'''
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'                super::g2_event(0,l.num_bits as usize,in_iter.bytes_left(),out_buf.bytes_left());\n')
start=s.index('fn decompress_fast(');end=s.index('\n/// Main decompression function.',start)
fast=s[start:end]
anchor='''    meter.charge(4096, 128, 1)?;
'''
assert fast.count(anchor)>=1
fast=fast.replace(anchor,'    super::g2_event(1,0,0,0);\n'+anchor,1)
anchor='''            apply_match(
'''
assert fast.count(anchor)==1
fast=fast.replace(anchor,'            super::g2_event(2,l.counter as usize,l.dist as usize,position);\n'+anchor)
s=s[:start]+fast+s[end:]
s+='''
// Diagnostic layout only; accepted core snapshots never gain this helper.
pub(super) fn g2_layout() -> [usize;6] {
    [::core::mem::size_of::<DecompressorOxide>(),::core::mem::align_of::<DecompressorOxide>(),
     ::core::mem::size_of::<LocalVars>(),::core::mem::align_of::<LocalVars>(),
     ::core::mem::size_of::<HuffmanTable>(),::core::mem::align_of::<HuffmanTable>()]
}
'''
p.write_text(s)
p=diag/'artifacts-under-test/src/zip_deflate_private/wrapper.rs';s=p.read_text()
s=s.replace('pub fn __g2_diagnostics() -> Option<DiagnosticReport> { None }','''static EVENTS:[AtomicUsize;3]=[const {AtomicUsize::new(0)};3];
static FIRST_GUARD:[AtomicUsize;3]=[const {AtomicUsize::new(0)};3];
static FIRST_MATCH:[AtomicUsize;3]=[const {AtomicUsize::new(0)};3];
static OVERFLOW:AtomicUsize=AtomicUsize::new(0);
fn g2_event(kind:usize,a:usize,b:usize,c:usize) {
    let before=EVENTS[kind].fetch_update(Ordering::SeqCst,Ordering::SeqCst,|n|if n<4096 {Some(n+1)}else{None});
    match before {
        Err(_)=>{OVERFLOW.store(1,Ordering::SeqCst);},
        Ok(0)=>{let target=if kind==0 {Some(&FIRST_GUARD)}else if kind==2 {Some(&FIRST_MATCH)}else{None};
            if let Some(t)=target {for (dst,v) in t.iter().zip([a,b,c]) {dst.store(v,Ordering::SeqCst);}}},
        _=>{},
    }
}
pub fn __g2_diagnostics()->Option<DiagnosticReport> {
    Some(DiagnosticReport {layouts:core::g2_layout(),guards:EVENTS[0].load(Ordering::SeqCst),
        first_guard:FIRST_GUARD.each_ref().map(|n|n.load(Ordering::SeqCst)),
        fast_entries:EVENTS[1].load(Ordering::SeqCst),fast_matches:EVENTS[2].load(Ordering::SeqCst),
        first_match:FIRST_MATCH.each_ref().map(|n|n.load(Ordering::SeqCst)),overflow:OVERFLOW.load(Ordering::SeqCst)!=0})
}''')
p.write_text(s)
print(json.dumps(dict(source_staged=True,accepted_core_unchanged=True,diagnostic_separate=True,cargo_resolution=False,compiler=False)))
