# T020 G2 standalone staged source — NOT compiled or executed

Root admitted source staging only on2026-10-14 at this exclusive tmp directory.
No product worktree/source/Cargo/lock/workflow changes. Source/lock review is
separate from compilation/runtime/executor admission. This is a finite resource
validation stage, never a delivered method8/product/semantic feature.

Read frozen proposal /private/tmp/ktlsp-t020-g2-packet/CONTRACT.md and HARNESS.md.
Core76 manifest aa7fa65729440ad4c998c5502ed8aa2d441cb23004c4b9087a8aaa4dde67c7ac.
Product base941c72efd9896b0847ab342ec0dd22c10a000f3b/treec9a8c8a;
assessed product50bef1c is a distinct earlier cutoff. Meter sourcefc7b5824 /
core32manifest22bfe1989b81d1758305b31c2aacaf1db72c960507120aa18705e2b078b000a3.

Source layout:
- artifacts-under-test is copied from frozen941; baseline145 hashes retained.
  Only Cargo.toml/lib.rs/zip_index.rs/zip_stored.rs change from baseline, plus
  new private decoder/wrapper/notices. All stored108 fixtures/tests remain exact.
- Shared selected-envelope extraction preserves method0's four relevant method/
  size/cap choices and carries its accumulated work to unchanged final stored
  payload debit/CRC. The original CRC body moves unchanged to private parent
  zip_index. Method8 wrapper lives in trusted decoder parent included at EOF.
- Accepted core/shared/output_buffer source are exact meter snapshots; parent is
  the exact snapshot prefix plus one include line. No accepted core probe/helper.
- diagnostic-copy has separate package/lock/executable identity, altered core
  guard/fast/match probes and private type-layout helper. It cannot supply accepted
  stack/physical measurements. Shared harness source is equal except its explicit
  diagnostic provenance flag. Diagnostic cohort requires actual slow/fast guard
  choices and match258/distance1/out_pos4.
- src/metrics.rs uses nonallocating atomic GlobalAlloc forwarding to System.
  Live System align1 pointers are observed while valid, before deallocation;
  a returned live Vec is checked against pointer/size/alignment before a second
  usable-size observation. No dangling/foreign/zero-capacity usable-size call.
  Loader/allocator identity remains unresolved until admitted Linux preflight.
- src/main.rs runs one case in verified guarded1MiB thread; exact literal errors,
  phases, heap/usable/RSS and private WorkLimit assertions are checked. Successful
  output stays alive through RSS/usable observation then explicit measured drop.
  RSS uses a preopened descriptor/reused16KiB buffer; maps use bounded64KiB
  storage with full-EOF checking. Recorded stack start/size/lower-guard size
  identify actual spans. K0-K6 calibrate exact hooks, failed-realloc ownership and ordinary panic FAIL.
  Negative stack control makes the entire4096-byte object escape across recursion;
  its emitted frame must be assessed before its separately admitted execution.
- supervise.rs serializes children, clears inherited loader/allocator environment,
  bounds pipe storage while continuing to drain, enforces10s direct-child deadline,
  and preserves OS cleanup/status before joins. Reap/join hangs remain HOLD.
  Per-artifact/profile root admission files bind source/graph/executor/ELF hashes;
  candidate cohort additionally requires matching successful calibration and
  complete compiled stack assessment<=262144. No admission files exist now. Small Rust unit checks cover bounded reads,
  proc fields, wire rejection and pipe error retention; source only, unexecuted.
- execution-route/PROPOSAL.md records actual gh availability/current workflow
  inventory and the minimal separately gated Linux workflow proposal. No standalone
  Linux executor is currently admitted. No workflow file/edit/dispatch is made.

Manual lock/source graph: each standalone lock contains13 packages:2 staged
packages plus11 pinned registry records, all original archives/checksums retained.
sha2=0.10.9 uses std/force-soft; adler2=2.0.1 no defaults/features. Lock retains
cpufeatures/libc target edges even where the admittedx86_64/force-soft branch
makes code unreachable. Lock membership is not linked reachability. No Cargo
resolution/metadata/fetch/install command ran; future --locked acceptance may
still reject the manual lock and then requires a reviewed graph correction.

GRAPH-AUDIT.json records full normal/target/build-dependency/features metadata.
Registry archives have no.c/.cc/.cpp/.cxx files. Existing generic-array Rust
build.rs uses version_check's Rust version probe; existing libc Rust build.rs
probes rustc --version and has other platform-only branches, not invoked here.
Only Linux GNU/x86_64 target/settings are proposed. No new first-party build
script, proc macro, C analysis engine, JVM/JDK, compressor, miniz package edge,
server/parser/oracle/bench dependency or native workflow is introduced.
Preserved third-party archive notices and copied miniz notices remain included.

Executed only source/data Python assertions, byte/hash/layout/CRC construction,
read-only Git/GitHub inventory and source review. No Rust/Cargo/fmt/clippy/tests,
decoder/compressor/interpreter/native/parser/worker/server/bench/oracle/JVM or
build tool. First data-check failure (line-count assertion counted a type
instead of only literal rows) is preserved under reviews; corrected check passes.

Compiled frame assessment must include overlapping harness observer/driver
storage and linked runtime/helper frames, not only decoder array sizes.

Next: same functionality/adversarial/architect review actual frozen stage+lock+
unsafe observation. Root must separately admit bound Linux preflight, compilation,
calibrations, complete stack assessment and named candidate runs. No automatic
transition, source->runtime inference, unchanged failure retry or weakened gate.

WorkLimit refusal does not establish compiled equivalence/useful dynamic coverage.
HDIST31/32 and descriptors stay separate, genuine Commons/Guava classes consumed0.
T008/T008a HOLD, broaderC13/B3/B4 GAP, B11 UNVERIFIED, #7/#83/#20 OPEN,
#96 OPEN/Darwin UNKNOWN. No G2PASS, fullT020, platform, comparativeperformance or
semantic/official parity claim.
