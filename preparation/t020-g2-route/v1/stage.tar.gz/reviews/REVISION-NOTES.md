# Source review corrections and retained evidence

The initial607-file staged source manifest c7e73edfe0673fb94a172500dd1e386ed8fe58987acd622f5e7d7e332358cddf
is retained as SOURCE-INITIAL.json and SOURCE-INITIAL.tar.gz. All actual initial
review reports are retained. Source-only checker first-failure note is separate:
its literal-row count originally also matched the Rust struct declaration; the
corrected data assertion counts only125 literal rows. No native failure occurred.

Pre-freeze draft review fixes: exact error fields and full phase counts; retain
successful output through RSS then explicit measured drop; non-optimized-away
negative control object source; diagnostic slow/fast branch checks; bounded pipe
capture and OS cleanup evidence before joins; env_clear and explicit K4/K5 FAIL
reasons; usable-size observation while error-path allocation is still live.
A stale-draft zero-output concern was explicitly withdrawn after actual frozen
snapshot0 readback; it was not a source defect or inferred runtime result.

Actual source revision1 fixes the remaining initial findings: preopened reusable
16KiB RSS observer and bounded64KiB maps/fullEOF; lower x86_64 guard only, actual
start address in receipt63; full calibration role/source/graph/executor/admission
binding and matching identity checks. It also bounds admission text/streams file
hashing and avoids slicing invalid returned core counts. Five small Rust unit
checks are staged for bounded reads, proc fields, wire rejection and pipe capture;
they are source only and have NOT been compiled/executed. Accepted core/fixtures/
wrapper/metrics/manual lock graphs did not change in this revision.

Final607-file source manifest59c355692dda28e57986ddc9d8f88b9e56666cf98fe30d60919e4fe2fb4d898b
has actual same-two correctness/adversarial + architect final readbacks. Their
approvals are SOURCE/GRAPH DATA ONLY. No Cargo-resolution, compiler, native test,
calibration, physical measurement, G2PASS, product/publication/CI admission follows.
