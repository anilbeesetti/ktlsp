use super::{ZipDirectoryIndex, ZipStoredError, crc32};
use std::sync::atomic::{AtomicUsize, Ordering};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ZipDeflateError {
    Envelope(ZipStoredError),
    DecodedLimit { offset: usize, limit: usize },
    Allocation { offset: usize },
    WorkLimit { offset: usize },
    DecodeRejected { offset: usize },
    TruncatedStream { offset: usize },
    OutputExceedsDeclared { offset: usize },
    TrailingCompressedBytes { offset: usize, consumed: usize, total: usize },
    DecodedSizeMismatch { offset: usize, expected: usize, actual: usize },
    CrcMismatch { offset: usize, expected: u32, actual: u32 },
    DecoderInvariant { offset: usize },
}
impl std::fmt::Display for ZipDeflateError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "ZIP deflate: {self:?}")
    }
}
impl std::error::Error for ZipDeflateError {}

#[derive(Clone, Copy, Default, Debug, Eq, PartialEq)]
pub struct ProbePhases {
    pub envelope: usize, pub reserve: usize, pub meter: usize, pub init: usize,
    pub raw: usize, pub crc: usize, pub publish: usize,
}
static PHASES: [AtomicUsize; 7] = [const { AtomicUsize::new(0) }; 7];
fn phase(n: usize) { PHASES[n].fetch_add(1, Ordering::SeqCst); }
pub fn __g2_phase_reset() { for n in &PHASES { n.store(0, Ordering::SeqCst); } }
pub fn __g2_phases() -> ProbePhases {
    let p = PHASES.each_ref().map(|n| n.load(Ordering::SeqCst));
    ProbePhases { envelope:p[0],reserve:p[1],meter:p[2],init:p[3],raw:p[4],crc:p[5],publish:p[6] }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u8)]
pub enum ProbeOutcome { Done=0, WorkLimit=1, DecodeRejected=2, TruncatedStream=3,
    OutputExceedsDeclared=4, DecoderInvariant=5 }
#[derive(Clone, Copy, Debug)]
pub struct CoreReport { pub outcome: ProbeOutcome, pub status: i8,
    pub consumed: usize, pub written: usize }
fn classify(status: TINFLStatus) -> ProbeOutcome {
    match status {
        TINFLStatus::Done => ProbeOutcome::Done,
        TINFLStatus::Failed => ProbeOutcome::DecodeRejected,
        TINFLStatus::FailedCannotMakeProgress => ProbeOutcome::TruncatedStream,
        TINFLStatus::HasMoreOutput => ProbeOutcome::OutputExceedsDeclared,
        _ => ProbeOutcome::DecoderInvariant,
    }
}
// Trusted stage-only caller prepares the exact zeroed slice before its core scope.
pub fn __g2_core(input: &[u8], output: &mut [u8]) -> CoreReport {
    phase(2);
    let Ok(meter) = core::WorkMeter::for_output(output.len()) else {
        return CoreReport { outcome:ProbeOutcome::WorkLimit,status:-127,consumed:usize::MAX,written:usize::MAX };
    };
    phase(4);
    match core::raw_once(input, output, meter) {
        Err(_) => CoreReport { outcome:ProbeOutcome::WorkLimit,status:-127,consumed:usize::MAX,written:usize::MAX },
        Ok((status, consumed, written)) => CoreReport { outcome:classify(status),status:status as i8,consumed,written },
    }
}
impl ZipDirectoryIndex<'_> {
    pub fn deflated_payload(&self, ordinal: usize) -> Result<Vec<u8>, ZipDeflateError> {
        phase(0);
        let selected = self.selected_envelope(ordinal, 8).map_err(ZipDeflateError::Envelope)?;
        let p = selected.payload_offset;
        let declared = usize::try_from(selected.declared).map_err(|_| ZipDeflateError::DecodedLimit {
            offset:selected.local_offset+22,limit:8_388_608 })?;
        if declared > 8_388_608 {
            return Err(ZipDeflateError::DecodedLimit {offset:selected.local_offset+22,limit:8_388_608});
        }
        let mut output = Vec::new();
        if declared > 0 {
            phase(1);
            output.try_reserve_exact(declared).map_err(|_| ZipDeflateError::Allocation {offset:p})?;
        }
        phase(2);
        let meter = core::WorkMeter::for_output(declared).map_err(|_| ZipDeflateError::WorkLimit {offset:p})?;
        phase(3);
        output.resize(declared, 0);
        phase(4);
        let (status, consumed, written) = core::raw_once(selected.payload, &mut output, meter)
            .map_err(|_| ZipDeflateError::WorkLimit {offset:p})?;
        if consumed > selected.payload.len() || written > output.len() {
            return Err(ZipDeflateError::DecoderInvariant {offset:p});
        }
        match classify(status) {
            ProbeOutcome::Done => {},
            ProbeOutcome::DecodeRejected => return Err(ZipDeflateError::DecodeRejected {offset:p}),
            ProbeOutcome::TruncatedStream => return Err(ZipDeflateError::TruncatedStream {offset:p}),
            ProbeOutcome::OutputExceedsDeclared => return Err(ZipDeflateError::OutputExceedsDeclared {offset:p}),
            _ => return Err(ZipDeflateError::DecoderInvariant {offset:p}),
        }
        if consumed != selected.payload.len() {
            return Err(ZipDeflateError::TrailingCompressedBytes {offset:p,consumed,total:selected.payload.len()});
        }
        if written != declared {
            return Err(ZipDeflateError::DecodedSizeMismatch {offset:p,expected:declared,actual:written});
        }
        phase(5);
        let actual = crc32(&output);
        if actual != selected.crc {
            return Err(ZipDeflateError::CrcMismatch {offset:p,expected:selected.crc,actual});
        }
        phase(6);
        Ok(output)
    }
}
#[derive(Clone, Copy, Debug, Default)]
pub struct DiagnosticReport {
    pub layouts: [usize; 6], pub guards: usize, pub first_guard: [usize; 3],
    pub fast_entries: usize, pub fast_matches: usize, pub first_match: [usize; 3],
    pub overflow: bool,
}
pub fn __g2_diagnostics() -> Option<DiagnosticReport> { None }
