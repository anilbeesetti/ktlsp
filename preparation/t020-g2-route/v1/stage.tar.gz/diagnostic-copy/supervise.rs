#[path="src/wire.rs"] mod wire;
#[path="src/cases.rs"] mod cases;
use std::io::Read;
use std::path::{Path,PathBuf};
use std::process::{Command,Stdio,ExitStatus};
use std::time::{Duration,Instant};
use std::os::unix::process::ExitStatusExt;
use sha2::{Digest,Sha256};
use wire::*;
fn hash(path:&Path)->std::io::Result<String> {
    let mut file=std::fs::File::open(path)?;let mut digest=Sha256::new();let mut buffer=[0u8;16384];
    loop {let n=file.read(&mut buffer)?;if n==0 {break;}digest.update(&buffer[..n]);}
    Ok(digest.finalize().iter().map(|b|format!("{b:02x}")).collect())
}
struct Capture {bytes:Vec<u8>,overflow:bool,error:Option<String>}
fn bounded(mut reader:impl Read,limit:usize)->Capture {
    let mut result=Vec::with_capacity(limit);let mut overflow=false;let mut buffer=[0;1024];
    loop {let n=match reader.read(&mut buffer) {Ok(n)=>n,Err(e)=>return Capture {bytes:result,overflow,error:Some(e.to_string())}};
        if n==0 {break;}let keep=n.min(limit-result.len());result.extend_from_slice(&buffer[..keep]);overflow |= keep<n;}
    Capture {bytes:result,overflow,error:None}
}
fn note(dir:&Path,phase:&str,error:&dyn std::fmt::Display) {
    let mut text=format!("{phase}: {error}\n");let end=text.char_indices().nth(1024).map_or(text.len(),|(n,_)|n);text.truncate(end);
    let _=std::fs::write(dir.join(format!("os-{phase}.txt")),text);
}
fn stop_reap(process:&mut std::process::Child,dir:&Path)->Option<ExitStatus> {
    match process.kill() {Ok(())=>note(dir,"kill",&"requested"),Err(e)=>note(dir,"kill",&e)}
    match process.wait() {Ok(s)=>{note(dir,"reap",&s);Some(s)},Err(e)=>{note(dir,"reap",&e);None}}
}
struct Observation {status:Option<ExitStatus>,out:Vec<u8>,err:Vec<u8>,overflow:bool,timeout:bool,os_error:bool}
fn child(binary:&Path,root:&Path,mode:&str,id:usize,dir:&Path)->std::io::Result<Observation> {
    std::fs::create_dir(dir)?;
    std::fs::write(dir.join("invocation.txt"),format!("{} {mode} {id} {}\n",binary.display(),root.display()))?;
    let mut process=match Command::new(binary).arg(mode).arg(id.to_string()).arg(root)
        .env_clear().env("LANG","C").env("LC_ALL","C")
        .stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped()).spawn() {
            Ok(p)=>p,Err(e)=>{note(dir,"spawn",&e);return Err(e);}};
    let out=process.stdout.take().unwrap();let err=process.stderr.take().unwrap();
    let stdout=match std::thread::Builder::new().spawn(move||bounded(out,BYTES)) {
        Ok(h)=>h,Err(e)=>{note(dir,"stdout-spawn",&e);stop_reap(&mut process,dir);return Err(e);}};
    let stderr=match std::thread::Builder::new().spawn(move||bounded(err,4096)) {
        Ok(h)=>Some(h),Err(e)=>{note(dir,"stderr-spawn",&e);None}};
    let start=Instant::now();let mut timeout=false;let mut os_error=stderr.is_none();
    let status=if os_error {stop_reap(&mut process,dir)} else {loop {
        match process.try_wait() {Ok(Some(s))=>break Some(s),Ok(None)=>{},
            Err(e)=>{note(dir,"try-wait",&e);os_error=true;break stop_reap(&mut process,dir);}}
        if start.elapsed()>=Duration::from_secs(10) {timeout=true;break stop_reap(&mut process,dir);}
        std::thread::sleep(Duration::from_millis(5));
    }};
    // Save completion/cleanup status BEFORE any potentially unconfirmed pipe join.
    std::fs::write(dir.join("status.txt"),format!("code={:?}\nsignal={:?}\ntimeout={timeout}\nos_error={os_error}\nelapsed_ms={}\n",
        status.as_ref().and_then(ExitStatus::code),status.as_ref().and_then(ExitStatusExt::signal),start.elapsed().as_millis()))?;
    let out=stdout.join().unwrap_or_else(|_|Capture {bytes:Vec::new(),overflow:false,error:Some("stdout join panic".into())});
    let err=match stderr {Some(h)=>h.join().unwrap_or_else(|_|Capture {bytes:Vec::new(),overflow:false,error:Some("stderr join panic".into())}),
        None=>Capture {bytes:Vec::new(),overflow:false,error:Some("stderr spawn".into())}};
    if let Some(e)=&out.error {os_error=true;note(dir,"stdout-read",e);}
    if let Some(e)=&err.error {os_error=true;note(dir,"stderr-read",e);}
    std::fs::write(dir.join("stdout.bin"),&out.bytes)?;std::fs::write(dir.join("stderr.bin"),&err.bytes)?;
    std::fs::write(dir.join("capture.txt"),format!("overflow={}\nos_error={os_error}\n",out.overflow||err.overflow))?;
    Ok(Observation {status,out:out.bytes,err:err.bytes,overflow:out.overflow||err.overflow,timeout,os_error})
}
fn normal(o:&Observation,id:usize,mode:u64)->Option<Receipt> {
    if o.timeout || o.overflow || !o.err.is_empty() || o.os_error || o.status.as_ref().and_then(ExitStatus::code)!=Some(0) {return None;}
    let r=decode(&o.out)?;
    (r[1]==id as u64 && r[2]==mode && r[3]==PASS && r[5]==0 && r[13]==1_048_576 && r[14]>=4096 && r[63]>=r[14] && r[63].checked_add(r[13]).is_some()).then_some(r)
}
fn calibration(binary:&Path,root:&Path,profile:&str,role:&str,evidence:&Path)->Result<(),String> {
    for id in 0..7 {
        let o=child(binary,root,"control",id,&evidence.join(format!("K{id}"))).map_err(|e|e.to_string())?;
        let r=decode(&o.out).ok_or("control receipt")?;
        let expected=match id {0=>[0;11],1=>[1,1,0,2,0,48,48,0,48,48,0],
            2=>[1,0,1,1,0,64,64,0,48,64,0],3=>[1,0,0,0,1,16,0,0,0,16,0],
            4=>[1,0,0,1,0,8,8,0,8,8,0],6=>[1,0,1,1,1,64,16,0,16,64,0],_=>[0;11]};
        let negative=id==4 || id==5;let code=if negative {70}else{0};
        if o.timeout || o.overflow || !o.err.is_empty() || o.os_error || o.status.as_ref().and_then(ExitStatus::code)!=Some(code)
            || r[59]!=(role=="diagnostic") as u64 || r[1]!=id as u64 || r[2]!=10 || r[3]!=code as u64 || r[60]!=1
            || r[13]!=1_048_576 || r[14]<4096 || r[63]<r[14] || r[63].checked_add(r[13]).is_none() || r[5]!=(id==5) as u64
            || r[4]!=(match id {3=>ALLOCATION,4=>16,5=>17,_=>SUCCESS}) || (id!=5 && r[15..26]!=expected) {return Err(format!("K{id} failed"));}
    }
    let o=child(binary,root,"stack-negative",0,&evidence.join("stack-negative")).map_err(|e|e.to_string())?;
    if o.timeout || o.overflow || o.os_error || o.out!=b"G2READY\n" || !matches!(o.status.as_ref().and_then(ExitStatusExt::signal),Some(6)|Some(11)) {
        return Err("stack negative failed".into());
    }
    std::fs::write(evidence.join(format!("CALIBRATION-{profile}.ok")),calibration_identity(root,binary,profile,role)?).map_err(|e|e.to_string())?;
    Ok(())
}
fn admission_text(path:&Path)->Result<String,String> {
    let file=std::fs::File::open(path).map_err(|e|e.to_string())?;
    let capture=bounded(file,4096);
    if capture.overflow{return Err("admission text overflow".into());}
    if let Some(error)=capture.error{return Err(error);}
    String::from_utf8(capture.bytes).map_err(|e|e.to_string())
}
fn identity_gate(root:&Path,binary:&Path,profile:&str,role:&str,execution:bool)->Result<(),String> {
    let kind=if execution {"EXECUTION"}else{"CALIBRATION"};
    let text=admission_text(&root.join(format!("{kind}-ADMISSION-{profile}-{role}.txt")))?;
    let mut values=std::collections::BTreeMap::new();
    for line in text.lines() {let (k,v)=line.split_once('=').ok_or("admission format")?;
        if values.insert(k,v).is_some(){return Err("duplicate admission field".into());}}
    if values.len()!=(if execution {9}else{7}) || values.get("approved")!=Some(&"root")
        || values.get("profile")!=Some(&profile) || values.get("role")!=Some(&role) {return Err("admission incomplete".into());}
    if execution {
        if values.get("compiled_stack")!=Some(&"complete"){return Err("compiled stack incomplete".into());}
        let stack=values.get("stack_bytes").ok_or("stack bytes")?.parse::<u64>().map_err(|_|"stack parse")?;
        if stack==0 || stack>262_144{return Err("stack ceiling".into());}
    }
    let actual_child=hash(binary).map_err(|e|e.to_string())?;
    let actual_source=hash(&root.join("SOURCE-HASHES.json")).map_err(|e|e.to_string())?;
    let lock=if role=="diagnostic" {"diagnostic-copy/Cargo.lock"}else{"Cargo.lock"};
    let actual_graph=hash(&root.join(lock)).map_err(|e|e.to_string())?;
    let actual_executor=hash(&root.join("evidence/EXECUTOR-BOUND.json")).map_err(|e|e.to_string())?;
    for (k,v) in [("child",actual_child),("source",actual_source),("graph",actual_graph),("executor",actual_executor)] {
        if values.get(k)!=Some(&v.as_str()){return Err(format!("admission {k} mismatch"));}
    }
    Ok(())
}
fn calibration_identity(root:&Path,binary:&Path,profile:&str,role:&str)->Result<String,String> {
    let lock=if role=="diagnostic" {"diagnostic-copy/Cargo.lock"}else{"Cargo.lock"};
    let admission=root.join(format!("CALIBRATION-ADMISSION-{profile}-{role}.txt"));
    Ok(format!("child={}\nprofile={profile}\nrole={role}\nsource={}\ngraph={}\nexecutor={}\ncalibration_admission={}\n",
        hash(binary).map_err(|e|e.to_string())?,hash(&root.join("SOURCE-HASHES.json")).map_err(|e|e.to_string())?,
        hash(&root.join(lock)).map_err(|e|e.to_string())?,hash(&root.join("evidence/EXECUTOR-BOUND.json")).map_err(|e|e.to_string())?,
        hash(&admission).map_err(|e|e.to_string())?))
}
fn admitted(root:&Path,binary:&Path,profile:&str,role:&str,calibration:&Path)->Result<(),String> {
    identity_gate(root,binary,profile,role,true)?;
    identity_gate(root,binary,profile,role,false)?;
    let cal=admission_text(&calibration.join(format!("CALIBRATION-{profile}.ok")))?;
    if cal!=calibration_identity(root,binary,profile,role)? {return Err("calibration identity".into());}
    Ok(())
}
fn run()->Result<(),String> {
    let args:Vec<String>=std::env::args().collect();
    if args.len()!=7{return Err("mode child root profile evidence calibration-directory".into());}
    let mode=&args[1];let binary=PathBuf::from(&args[2]);let root=PathBuf::from(&args[3]);
    let profile=&args[4];if profile!="D" && profile!="R"{return Err("profile".into());}
    let evidence=PathBuf::from(&args[5]);std::fs::create_dir(&evidence).map_err(|e|e.to_string())?;
    let calibration_dir=PathBuf::from(&args[6]);
    if mode=="calibrate" || mode=="calibrate-diagnostic" {
        let role=if mode=="calibrate" {"accepted"}else{"diagnostic"};
        identity_gate(&root,&binary,profile,role,false)?;
        return calibration(&binary,&root,profile,role,&evidence);
    }
    let role=if mode=="diagnostic" {"diagnostic"}else{"accepted"};
    admitted(&root,&binary,profile,role,&calibration_dir)?;
    if mode=="diagnostic" {
        for c in cases::CASES.iter().filter(|c|matches!(c.name,"fast-declared326"|"fast-prefix14"|"fast-prefix15"|"fast-prefix16")) {
            let o=child(&binary,&root,"core",c.id,&evidence.join(format!("diagnostic-{}",c.id))).map_err(|e|e.to_string())?;
            let r=normal(&o,c.id,1).ok_or("diagnostic failure")?;
            if r[59]!=1 || r[57]!=0 || r[48]==0{return Err("diagnostic provenance/events".into());}
        }
        return Ok(());
    }
    if mode!="candidate"{return Err("mode".into());}
    for c in cases::CASES {
        for (name,m) in [("wrapper",0),("core",1)] {
            if m==1 && c.precondition {continue;}
            let o=child(&binary,&root,name,c.id,&evidence.join(format!("{name}-{}",c.id))).map_err(|e|e.to_string())?;
            let r=normal(&o,c.id,m).ok_or_else(||format!("{} {name} failed",c.name))?;
            if r[59]!=0 || (r[4]!=c.expected && !(r[4]==WORK_LIMIT && c.allow_worklimit)
                && !(m==1 && matches!(c.expected,TRAILING|SIZE_MISMATCH|CRC_MISMATCH) && r[4]==SUCCESS)) {
                return Err("outcome or accepted provenance".into());
            }
        }
    }
    for name in ["old-fixed-A","declared-cap+0"] {
        let c=cases::CASES.iter().find(|c|c.name==name).ok_or("failure-injection case")?;
        let o=child(&binary,&root,"allocation-failure",c.id,&evidence.join(format!("allocation-{}",c.id))).map_err(|e|e.to_string())?;
        let r=normal(&o,c.id,2).ok_or("allocation failure calibration")?;
        if r[4]!=ALLOCATION || r[59]!=0{return Err("allocation failure receipt".into());}
    }
    Ok(())
}
fn main(){if let Err(error)=run(){eprintln!("G2 HOLD: {error}");std::process::exit(70);}}

#[cfg(test)]
mod pipe_tests {
    use super::*;
    #[test]
    fn storage_is_bounded_while_reader_drains() {
        let capture=bounded(std::io::Cursor::new(b"123456"),4);
        assert_eq!(capture.bytes,b"1234");assert!(capture.overflow);assert!(capture.error.is_none());
    }
    struct Fault(bool);
    impl Read for Fault {
        fn read(&mut self,out:&mut [u8])->std::io::Result<usize> {
            if self.0{return Err(std::io::Error::other("injected read"));}
            self.0=true;out[..2].copy_from_slice(b"ok");Ok(2)
        }
    }
    #[test]
    fn read_fault_preserves_already_captured_bytes() {
        let capture=bounded(Fault(false),4);assert_eq!(capture.bytes,b"ok");assert!(capture.error.is_some());
    }
}
