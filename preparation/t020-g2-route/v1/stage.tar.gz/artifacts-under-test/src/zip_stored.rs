use super::{
    ZipDirectoryIndex, ZipIndexError, charge, crc32,
};

#[cfg(test)]
use super::{MAX_EXTRA, MAX_NAME};

#[cfg(test)]
const MAX_PAYLOAD: usize = 8 * 1024 * 1024;
const MAX_WORK: usize = 16 * 1024 * 1024;

/// Selected-entry errors contain only numeric values and static labels.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ZipStoredError {
    InvalidOrdinal {
        ordinal: usize,
        entries: usize,
    },
    Structure(ZipIndexError),
    Disagreement {
        offset: usize,
        field: &'static str,
    },
    Overlap {
        offset: usize,
        other_ordinal: usize,
    },
    CrcMismatch {
        offset: usize,
        expected: u32,
        actual: u32,
    },
}

impl std::fmt::Display for ZipStoredError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "ZIP stored payload: {self:?}")
    }
}

impl std::error::Error for ZipStoredError {}

impl<'a> ZipDirectoryIndex<'a> {
    /// Borrow one method-0 payload from this index's retained artifact, by
    /// central-record ordinal. Bounds, agreement and declared-envelope overlap
    /// checks precede ZIP CRC-32 verification. No names select a duplicate winner.
    ///
    /// Descriptor tails, unselected CRC/agreement and whole-archive validity
    /// remain unchecked. Limits apply to each call, not a session; see ZIP_STORED.md.
    ///
    /// ```compile_fail
    /// use ktlsp_artifacts::{ZipDirectoryIndex, VerifiedArtifact};
    /// fn mismatch(index: &ZipDirectoryIndex<'_>, other: &VerifiedArtifact) {
    ///     index.stored_payload(0, other);
    /// }
    /// ```
    /// ```compile_fail
    /// use ktlsp_artifacts::{ZipDirectoryIndex, ZipDirectoryEntry};
    /// fn arbitrary_entry(index: &ZipDirectoryIndex<'_>, entry: &ZipDirectoryEntry<'_>) {
    ///     index.stored_payload(entry);
    /// }
    /// ```
    /// ```compile_fail
    /// use ktlsp_artifacts::ZipDirectoryIndex;
    /// fn mutate(index: &ZipDirectoryIndex<'_>) {
    ///     index.stored_payload(0).unwrap()[0] = 1;
    /// }
    /// ```
    /// ```compile_fail
    /// use ktlsp_artifacts::{VerifiedArtifact, index_zip_directory};
    /// fn escape(artifact: VerifiedArtifact) -> &'static [u8] {
    ///     index_zip_directory(&artifact).unwrap().stored_payload(0).unwrap()
    /// }
    /// ```
    pub fn stored_payload(&self, ordinal: usize) -> Result<&'a [u8], ZipStoredError> {
        let selected = self.selected_envelope(ordinal, 0)?;
        let mut work = selected.work;
        let size = selected.payload.len();
        let p = selected.payload_offset;
        let payload = selected.payload;
        let expected = selected.crc;
        charge(&mut work, size, MAX_WORK, p, "stored work units")
            .map_err(ZipStoredError::Structure)?;
        let actual = crc32(payload);
        if actual != expected {
            return Err(ZipStoredError::CrcMismatch {
                offset: p,
                expected,
                actual,
            });
        }
        Ok(payload)
    }
}


#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn work_budget_is_atomic_and_overflow_checked() {
        let mut work = MAX_WORK - 1;
        charge(&mut work, 1, MAX_WORK, 7, "stored work units").unwrap();
        for amount in [1, usize::MAX] {
            assert_eq!(
                charge(&mut work, amount, MAX_WORK, 7, "stored work units"),
                Err(ZipIndexError::Limit {
                    offset: 7,
                    field: "stored work units",
                    limit: MAX_WORK
                })
            );
            assert_eq!(work, MAX_WORK);
        }
        const {
            assert!(
                31 * super::super::MAX_ENTRIES + MAX_NAME + MAX_EXTRA + MAX_PAYLOAD == 8_916_992
            );
        }
        const {
            assert!(8_916_992 < MAX_WORK);
        }
    }
}
